package Utilidades;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;

public class CsvEmpleados {

    public static void guardarEmpleado(Empleado empleado, String nombreArchivo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo, true))) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            writer.write(empleado.getNombre() + "," 
                       + empleado.getApellido() + "," 
                       + empleado.getEmail() + "," 
                       + empleado.getNumeroTelefono() + "," 
                       + empleado.getTipoDocumento() + "," 
                       + empleado.getNumDocumento() + "," 
                       + empleado.getNacionalidad() + "," 
                       + empleado.getPassword() + "," 
                       + empleado.getCargo() + "," 
                       + sdf.format(empleado.getFechaDeInicio()) + "," 
                       + empleado.getCalificacion() + "," 
                       + empleado.getSalario() + "," 
                       + empleado.getNumCelular());
            writer.newLine();
            System.out.println("Información guardada exitosamente.");
        } catch (IOException e) {
            System.out.println("Error al guardar la información: " + e.getMessage());
        }
    }
}
