/*package Utilidades;

import com.itextpdf.
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;

public class FacturaPDF {

public static void generarFactura(Factura factura, String nombreArchivo) {
try {
// Crear el escritor PDF
PdfWriter writer = new PdfWriter(nombreArchivo);
PdfDocument pdfDocument = new PdfDocument(writer);
Document document = new Document(pdfDocument);

// Agregar título
document.add(new Paragraph("Factura").setBold().setFontSize(18).setMultipliedLeading(1.5f));

// Agregar información de la factura
SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
document.add(new Paragraph("Número de Factura: " + factura.getNumFactura()));
document.add(new Paragraph("Fecha: " + sdf.format(factura.getFecha())));
document.add(new Paragraph("Propietario: " + factura.getPropietario().getNombreCompleto())); // Asumiendo que hay un método en Propietario que devuelve el nombre completo

// Tabla con detalles de la factura
Table table = new Table(3);
table.addCell("Concepto");
table.addCell("Valor");
table.addCell("Total");

table.addCell("Valor de la factura");
table.addCell(String.valueOf(factura.getValor()));
table.addCell("");

table.addCell("Valor de administración");
table.addCell(String.valueOf(factura.getValorAdmon()));
table.addCell("");

if (factura.isMultas()) {
table.addCell("Valor de multas");
table.addCell(String.valueOf(factura.getValorMultas()));
table.addCell("");
}

if (factura.isCtasVencidas()) {
table.addCell("Valor de cuentas vencidas");
table.addCell(String.valueOf(factura.getValorCtasVencidas()));
table.addCell("");
}

table.addCell("Total a pagar");
table.addCell("");
table.addCell(String.valueOf(factura.getTotal()));

document.add(table);

// Cerrar el documento
document.close();
System.out.println("Factura generada exitosamente: " + nombreArchivo);
} catch (FileNotFoundException e) {
System.out.println("Error al generar el archivo PDF: " + e.getMessage());
}
}
}*/