package com.mycompany.Windows;


public class MenuPrincipal extends javax.swing.JFrame {

    public MenuPrincipal() {
    initComponents();  // Inicializa los componentes de la ventana
    setLocationRelativeTo(null);
    pack();
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Bienvenido = new javax.swing.JLabel();
        MenuPricipal = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        Titulo = new javax.swing.JLabel();
        Salir = new javax.swing.JButton();
        AreasComunes = new javax.swing.JButton();
        Empleados = new javax.swing.JButton();
        Multas = new javax.swing.JButton();
        Propiedades = new javax.swing.JButton();
        Propietarios = new javax.swing.JButton();
        Facturacion = new javax.swing.JButton();
        Logo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(900, 600));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(200, 215, 189));
        jPanel1.setMaximumSize(new java.awt.Dimension(900, 600));
        jPanel1.setMinimumSize(new java.awt.Dimension(900, 600));
        jPanel1.setPreferredSize(new java.awt.Dimension(900, 600));
        jPanel1.setRequestFocusEnabled(false);
        jPanel1.setVerifyInputWhenFocusTarget(false);
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Bienvenido.setFont(new java.awt.Font("Amaranth", 1, 56)); // NOI18N
        Bienvenido.setForeground(new java.awt.Color(0, 0, 0));
        Bienvenido.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Bienvenido.setText("Bienvenido");
        Bienvenido.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel1.add(Bienvenido, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 900, -1));

        MenuPricipal.setFont(new java.awt.Font("Amaranth", 0, 18)); // NOI18N
        MenuPricipal.setForeground(new java.awt.Color(0, 51, 16));
        MenuPricipal.setText("Menu Principal");
        jPanel1.add(MenuPricipal, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 320, -1, -1));

        jSeparator1.setToolTipText("");
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 880, 10));

        Titulo.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Titulo.setForeground(new java.awt.Color(0, 51, 16));
        Titulo.setText("Santa Mónica Campestre");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        Salir.setBackground(new java.awt.Color(159, 191, 166));
        Salir.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Salir.setForeground(new java.awt.Color(0, 0, 0));
        Salir.setText("Salir");
        Salir.setToolTipText("");
        Salir.setBorderPainted(false);
        Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirActionPerformed(evt);
            }
        });
        jPanel1.add(Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 10, -1, -1));

        AreasComunes.setBackground(new java.awt.Color(200, 215, 189));
        AreasComunes.setFont(new java.awt.Font("Montserrat", 1, 22)); // NOI18N
        AreasComunes.setForeground(new java.awt.Color(0, 0, 0));
        AreasComunes.setText("AREAS COMUNES");
        AreasComunes.setBorderPainted(false);
        AreasComunes.setContentAreaFilled(false);
        AreasComunes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AreasComunesActionPerformed(evt);
            }
        });
        jPanel1.add(AreasComunes, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 50, -1, -1));

        Empleados.setBackground(new java.awt.Color(200, 215, 189));
        Empleados.setFont(new java.awt.Font("Montserrat", 1, 22)); // NOI18N
        Empleados.setForeground(new java.awt.Color(0, 0, 0));
        Empleados.setText("EMPLEADOS");
        Empleados.setBorderPainted(false);
        Empleados.setContentAreaFilled(false);
        Empleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmpleadosActionPerformed(evt);
            }
        });
        jPanel1.add(Empleados, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, -1));

        Multas.setBackground(new java.awt.Color(200, 215, 189));
        Multas.setFont(new java.awt.Font("Montserrat", 1, 22)); // NOI18N
        Multas.setForeground(new java.awt.Color(0, 0, 0));
        Multas.setText("MULTAS");
        Multas.setBorderPainted(false);
        Multas.setContentAreaFilled(false);
        Multas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MultasActionPerformed(evt);
            }
        });
        jPanel1.add(Multas, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 500, -1, -1));

        Propiedades.setBackground(new java.awt.Color(200, 215, 189));
        Propiedades.setFont(new java.awt.Font("Montserrat", 1, 22)); // NOI18N
        Propiedades.setForeground(new java.awt.Color(0, 0, 0));
        Propiedades.setText("PROPIEDADES");
        Propiedades.setBorderPainted(false);
        Propiedades.setContentAreaFilled(false);
        Propiedades.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PropiedadesActionPerformed(evt);
            }
        });
        jPanel1.add(Propiedades, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, -1, -1));

        Propietarios.setBackground(new java.awt.Color(200, 215, 189));
        Propietarios.setFont(new java.awt.Font("Montserrat", 1, 22)); // NOI18N
        Propietarios.setForeground(new java.awt.Color(0, 0, 0));
        Propietarios.setText("PROPIETARIOS");
        Propietarios.setBorderPainted(false);
        Propietarios.setContentAreaFilled(false);
        Propietarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PropietariosActionPerformed(evt);
            }
        });
        jPanel1.add(Propietarios, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 50, -1, -1));

        Facturacion.setBackground(new java.awt.Color(200, 215, 189));
        Facturacion.setFont(new java.awt.Font("Montserrat", 1, 22)); // NOI18N
        Facturacion.setForeground(new java.awt.Color(0, 0, 0));
        Facturacion.setText("FACTURACIÓN");
        Facturacion.setBorderPainted(false);
        Facturacion.setContentAreaFilled(false);
        Facturacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FacturacionActionPerformed(evt);
            }
        });
        jPanel1.add(Facturacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 500, -1, -1));

        Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Santa Monica Campestre (128 x 128 px)(3).png"))); // NOI18N
        jPanel1.add(Logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 420, -1, 140));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/HOJA.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 200, -1));

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirActionPerformed
        Login login = new Login();
        login.setVisible(true);
        login.setLocationRelativeTo(null);
        setSize(900, 600);
        dispose();
    }//GEN-LAST:event_SalirActionPerformed

    private void EmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmpleadosActionPerformed
        MenuEmpleados mEmpleados = new MenuEmpleados();
        mEmpleados.setVisible(true);
        mEmpleados.setLocationRelativeTo(null);
        setSize(900, 600);
        dispose();
    }//GEN-LAST:event_EmpleadosActionPerformed

    private void PropietariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PropietariosActionPerformed
        MenuPropietarios mPropietarios = new MenuPropietarios();
        mPropietarios.setVisible(true);
        mPropietarios.setLocationRelativeTo(null);
        setSize(900, 600);
        dispose();
    }//GEN-LAST:event_PropietariosActionPerformed

    private void FacturacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FacturacionActionPerformed
        MenuFacturacion mFacturacion = new MenuFacturacion();
        mFacturacion.setVisible(true);
        mFacturacion.setLocationRelativeTo(null);
        setSize(900, 600);
        dispose();
    }//GEN-LAST:event_FacturacionActionPerformed

    private void MultasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MultasActionPerformed
        MenuMultas mMultas = new MenuMultas();
        mMultas.setVisible(true);
        mMultas.setLocationRelativeTo(null);
        setSize(900, 600);
        dispose();
    }//GEN-LAST:event_MultasActionPerformed

    private void PropiedadesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PropiedadesActionPerformed
        MenuPropiedades mPropiedades = new MenuPropiedades();
        mPropiedades.setVisible(true);
        mPropiedades.setLocationRelativeTo(null);
        setSize(900, 600);
        dispose();
    }//GEN-LAST:event_PropiedadesActionPerformed

    private void AreasComunesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AreasComunesActionPerformed
        MenuAreasComunes mAreasComunes = new MenuAreasComunes();
        mAreasComunes.setVisible(true);
        mAreasComunes.setLocationRelativeTo(null);
        setSize(900, 600);
        dispose();
    }//GEN-LAST:event_AreasComunesActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AreasComunes;
    private javax.swing.JLabel Bienvenido;
    private javax.swing.JButton Empleados;
    private javax.swing.JButton Facturacion;
    private javax.swing.JLabel Logo;
    private javax.swing.JLabel MenuPricipal;
    private javax.swing.JButton Multas;
    private javax.swing.JButton Propiedades;
    private javax.swing.JButton Propietarios;
    private javax.swing.JButton Salir;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
