package com.mycompany.Windows;

import com.mycompany.Utilidades.FacturaPDF;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;




public class GenerarFactura extends javax.swing.JFrame {

    public GenerarFactura() {
    initComponents();  // Inicializa los componentes de la ventana
    setLocationRelativeTo(null);
    pack();
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        Titulo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        GenerarPDF = new javax.swing.JButton();
        Guardar = new javax.swing.JButton();
        Salir1 = new javax.swing.JButton();
        Apellido = new javax.swing.JTextField();
        NumeroId = new javax.swing.JTextField();
        CtasVencidas = new javax.swing.JComboBox<>();
        ValorCtasVnecidas = new javax.swing.JTextField();
        Nombre = new javax.swing.JTextField();
        NumPropiedad = new javax.swing.JTextField();
        ValorAdmon = new javax.swing.JTextField();
        Total = new javax.swing.JTextField();
        NumeroFactura = new javax.swing.JTextField();
        Fecha = new javax.swing.JTextField();
        TipoDocumento = new javax.swing.JComboBox<>();
        Descuentos = new javax.swing.JComboBox<>();
        ValorDescuentos = new javax.swing.JTextField();
        Multas = new javax.swing.JComboBox<>();
        ValorMultas = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        Cancelar1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(900, 600));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(159, 191, 166));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator1.setToolTipText("");
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 880, 10));

        Titulo.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Titulo.setForeground(new java.awt.Color(0, 51, 16));
        Titulo.setText("Generar Factura");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/LETRAS.png"))); // NOI18N
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 500, -1, 50));

        GenerarPDF.setBackground(new java.awt.Color(165, 159, 191));
        GenerarPDF.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        GenerarPDF.setForeground(new java.awt.Color(0, 0, 0));
        GenerarPDF.setText("Generar PDF");
        GenerarPDF.setToolTipText("");
        GenerarPDF.setBorderPainted(false);
        GenerarPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GenerarPDFActionPerformed(evt);
            }
        });
        jPanel1.add(GenerarPDF, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 530, -1, -1));

        Guardar.setBackground(new java.awt.Color(92, 123, 105));
        Guardar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Guardar.setForeground(new java.awt.Color(0, 0, 0));
        Guardar.setText("Guardar");
        Guardar.setToolTipText("");
        Guardar.setBorderPainted(false);
        Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarActionPerformed(evt);
            }
        });
        jPanel1.add(Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 530, -1, -1));

        Salir1.setBackground(new java.awt.Color(92, 123, 105));
        Salir1.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Salir1.setForeground(new java.awt.Color(0, 0, 0));
        Salir1.setText("Atrás");
        Salir1.setToolTipText("");
        Salir1.setBorderPainted(false);
        Salir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Salir1ActionPerformed(evt);
            }
        });
        jPanel1.add(Salir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 10, -1, -1));

        Apellido.setBackground(new java.awt.Color(255, 255, 255));
        Apellido.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Apellido.setForeground(new java.awt.Color(153, 153, 153));
        Apellido.setText("Apellido");
        Apellido.setBorder(null);
        Apellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ApellidoActionPerformed(evt);
            }
        });
        jPanel1.add(Apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 70, 430, 30));

        NumeroId.setBackground(new java.awt.Color(255, 255, 255));
        NumeroId.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NumeroId.setForeground(new java.awt.Color(153, 153, 153));
        NumeroId.setText("Numero de Documento");
        NumeroId.setToolTipText("");
        NumeroId.setBorder(null);
        NumeroId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumeroIdActionPerformed(evt);
            }
        });
        jPanel1.add(NumeroId, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 120, 650, 30));

        CtasVencidas.setBackground(new java.awt.Color(255, 255, 255));
        CtasVencidas.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        CtasVencidas.setForeground(new java.awt.Color(0, 0, 0));
        CtasVencidas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ctas Vencidas", "Si", "No" }));
        CtasVencidas.setBorder(null);
        CtasVencidas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CtasVencidasActionPerformed(evt);
            }
        });
        jPanel1.add(CtasVencidas, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 220, 140, 30));

        ValorCtasVnecidas.setBackground(new java.awt.Color(255, 255, 255));
        ValorCtasVnecidas.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        ValorCtasVnecidas.setForeground(new java.awt.Color(153, 153, 153));
        ValorCtasVnecidas.setText("Valor Ctas Vencidas");
        ValorCtasVnecidas.setBorder(null);
        ValorCtasVnecidas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ValorCtasVnecidasActionPerformed(evt);
            }
        });
        jPanel1.add(ValorCtasVnecidas, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 220, 280, 30));

        Nombre.setBackground(new java.awt.Color(255, 255, 255));
        Nombre.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Nombre.setForeground(new java.awt.Color(153, 153, 153));
        Nombre.setText("Nombre");
        Nombre.setBorder(null);
        Nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreActionPerformed(evt);
            }
        });
        jPanel1.add(Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 430, 30));

        NumPropiedad.setBackground(new java.awt.Color(255, 255, 255));
        NumPropiedad.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NumPropiedad.setForeground(new java.awt.Color(153, 153, 153));
        NumPropiedad.setText("Numero de Propiedad");
        NumPropiedad.setBorder(null);
        NumPropiedad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumPropiedadActionPerformed(evt);
            }
        });
        jPanel1.add(NumPropiedad, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 430, 30));

        ValorAdmon.setBackground(new java.awt.Color(255, 255, 255));
        ValorAdmon.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        ValorAdmon.setForeground(new java.awt.Color(153, 153, 153));
        ValorAdmon.setText("Valor Administración");
        ValorAdmon.setBorder(null);
        ValorAdmon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ValorAdmonActionPerformed(evt);
            }
        });
        jPanel1.add(ValorAdmon, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 170, 430, 30));

        Total.setBackground(new java.awt.Color(255, 255, 255));
        Total.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Total.setForeground(new java.awt.Color(153, 153, 153));
        Total.setText("Total");
        Total.setBorder(null);
        Total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TotalActionPerformed(evt);
            }
        });
        jPanel1.add(Total, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 380, 420, 30));

        NumeroFactura.setBackground(new java.awt.Color(255, 255, 255));
        NumeroFactura.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NumeroFactura.setForeground(new java.awt.Color(153, 153, 153));
        NumeroFactura.setText("Numero de Factura");
        NumeroFactura.setBorder(null);
        NumeroFactura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumeroFacturaActionPerformed(evt);
            }
        });
        jPanel1.add(NumeroFactura, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 430, 30));

        Fecha.setBackground(new java.awt.Color(255, 255, 255));
        Fecha.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Fecha.setForeground(new java.awt.Color(153, 153, 153));
        Fecha.setText("Fecha");
        Fecha.setBorder(null);
        Fecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FechaActionPerformed(evt);
            }
        });
        jPanel1.add(Fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 430, 30));

        TipoDocumento.setBackground(new java.awt.Color(255, 255, 255));
        TipoDocumento.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        TipoDocumento.setForeground(new java.awt.Color(0, 0, 0));
        TipoDocumento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tipo de Documento", "C.C", "C.E", "Pasaporte", "T.I", "NUI", "R.C" }));
        TipoDocumento.setBorder(null);
        TipoDocumento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoDocumentoActionPerformed(evt);
            }
        });
        jPanel1.add(TipoDocumento, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 220, 30));

        Descuentos.setBackground(new java.awt.Color(255, 255, 255));
        Descuentos.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Descuentos.setForeground(new java.awt.Color(0, 0, 0));
        Descuentos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Descuentos", "Si", "No" }));
        Descuentos.setBorder(null);
        Descuentos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DescuentosActionPerformed(evt);
            }
        });
        jPanel1.add(Descuentos, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 140, 30));

        ValorDescuentos.setBackground(new java.awt.Color(255, 255, 255));
        ValorDescuentos.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        ValorDescuentos.setForeground(new java.awt.Color(153, 153, 153));
        ValorDescuentos.setText("Valor Descuentos");
        ValorDescuentos.setBorder(null);
        ValorDescuentos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ValorDescuentosActionPerformed(evt);
            }
        });
        jPanel1.add(ValorDescuentos, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 270, 280, 30));

        Multas.setBackground(new java.awt.Color(255, 255, 255));
        Multas.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Multas.setForeground(new java.awt.Color(0, 0, 0));
        Multas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Multas", "Si", "No" }));
        Multas.setBorder(null);
        Multas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MultasActionPerformed(evt);
            }
        });
        jPanel1.add(Multas, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 140, 30));

        ValorMultas.setBackground(new java.awt.Color(255, 255, 255));
        ValorMultas.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        ValorMultas.setForeground(new java.awt.Color(153, 153, 153));
        ValorMultas.setText("Valor Multas");
        ValorMultas.setBorder(null);
        ValorMultas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ValorMultasActionPerformed(evt);
            }
        });
        jPanel1.add(ValorMultas, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 220, 280, 30));

        jLabel1.setBackground(new java.awt.Color(204, 255, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/HOJA.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 900, -1));

        Cancelar1.setBackground(new java.awt.Color(92, 123, 105));
        Cancelar1.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Cancelar1.setForeground(new java.awt.Color(0, 0, 0));
        Cancelar1.setText("Cancelar");
        Cancelar1.setToolTipText("");
        Cancelar1.setBorderPainted(false);
        Cancelar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Cancelar1ActionPerformed(evt);
            }
        });
        jPanel1.add(Cancelar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 530, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NumeroIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumeroIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumeroIdActionPerformed

    private void ApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ApellidoActionPerformed

    private void Salir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Salir1ActionPerformed
        MenuFacturacion mFacturacion = new MenuFacturacion();
        mFacturacion.setVisible(true);
        mFacturacion.setLocationRelativeTo(null);
        pack();
        dispose();
    }//GEN-LAST:event_Salir1ActionPerformed

    private void GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarActionPerformed
        String nombre = Nombre.getText();
        String apellido = Apellido.getText();
        String numeroId = NumeroId.getText();
        String numPropiedad = NumPropiedad.getText();
        String valorAdmon = ValorAdmon.getText();
        String total = Total.getText();
        String fecha = Fecha.getText();
        String numeroFactura = NumeroFactura.getText();
        String valorMultas = ValorMultas.getText();
        String valorCtasVencidas = ValorCtasVnecidas.getText();
        String valorDescuentos = ValorDescuentos.getText();
        String tipoId = TipoDocumento.getSelectedItem().toString();
        String multas = Multas.getSelectedItem().toString();
        String descuentos = Descuentos.getSelectedItem().toString();
        String cuentasVencidas = CtasVencidas.getSelectedItem().toString();

    // Define la ruta del archivo CSV en la carpeta 'data'
    String filePath = "data/facturas.csv";

    // Intenta escribir en el archivo CSV
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
        // Escribe una línea con los datos separados por comas
        writer.write(String.join(",", nombre, apellido, tipoId, numeroId, numPropiedad, valorAdmon, multas, valorMultas, cuentasVencidas, valorCtasVencidas, descuentos, valorDescuentos, total, fecha, numeroFactura));
        writer.newLine(); // Añade una nueva línea
        JOptionPane.showMessageDialog(this, "Factura guardada exitosamente en " + filePath);
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error al guardar la factura: " + e.getMessage());
    }
    }//GEN-LAST:event_GuardarActionPerformed

    private void GenerarPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GenerarPDFActionPerformed
    FacturaPDF pdfGenerator = new FacturaPDF();
    pdfGenerator.generateInvoice(
        Nombre.getText(),
        Apellido.getText(),
        TipoDocumento.getSelectedItem().toString(),
        NumeroId.getText(),
        NumPropiedad.getText(),
        ValorAdmon.getText(),
        Multas.getSelectedItem().toString(),
        ValorMultas.getText(),
        Descuentos.getSelectedItem().toString(),
        ValorDescuentos.getText(),
        CtasVencidas.getSelectedItem().toString(),
        ValorCtasVnecidas.getText(),
        Total.getText(),
        Fecha.getText(),
        NumeroFactura.getText()
    );

    }//GEN-LAST:event_GenerarPDFActionPerformed

    private void CtasVencidasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CtasVencidasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CtasVencidasActionPerformed

    private void ValorCtasVnecidasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ValorCtasVnecidasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ValorCtasVnecidasActionPerformed

    private void NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreActionPerformed

    private void NumPropiedadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumPropiedadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumPropiedadActionPerformed

    private void ValorAdmonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ValorAdmonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ValorAdmonActionPerformed

    private void TotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TotalActionPerformed

    private void NumeroFacturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumeroFacturaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumeroFacturaActionPerformed

    private void FechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FechaActionPerformed

    private void TipoDocumentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoDocumentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TipoDocumentoActionPerformed

    private void DescuentosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DescuentosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DescuentosActionPerformed

    private void ValorDescuentosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ValorDescuentosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ValorDescuentosActionPerformed

    private void MultasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MultasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MultasActionPerformed

    private void ValorMultasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ValorMultasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ValorMultasActionPerformed

    private void Cancelar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Cancelar1ActionPerformed
         // Clear all text fields
        Apellido.setText("Apellido");
        Fecha.setText("Fecha");
        ValorDescuentos.setText("Valor Descuentos");
        Nombre.setText("Nombre");
        NumPropiedad.setText("Numero de Propiedad");
        NumeroFactura.setText("Numero de Factura");
        NumeroId.setText("Numero de Documento");
        Total.setText("Toal");
        ValorAdmon.setText("Valor Administración");
        ValorCtasVnecidas.setText("Valor cuenas vencidas");
        ValorMultas.setText("Valor Multas");

        // Reset combo boxes to their default selection (assuming the first item is the default)
        TipoDocumento.setSelectedIndex(0);
        Descuentos.setSelectedIndex(0);
        CtasVencidas.setSelectedIndex(0);
        Multas.setSelectedIndex(0);
    
    }//GEN-LAST:event_Cancelar1ActionPerformed
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Apellido;
    private javax.swing.JButton Cancelar1;
    private javax.swing.JComboBox<String> CtasVencidas;
    private javax.swing.JComboBox<String> Descuentos;
    private javax.swing.JTextField Fecha;
    private javax.swing.JButton GenerarPDF;
    private javax.swing.JButton Guardar;
    private javax.swing.JComboBox<String> Multas;
    private javax.swing.JTextField Nombre;
    private javax.swing.JTextField NumPropiedad;
    private javax.swing.JTextField NumeroFactura;
    private javax.swing.JTextField NumeroId;
    private javax.swing.JButton Salir1;
    private javax.swing.JComboBox<String> TipoDocumento;
    private javax.swing.JLabel Titulo;
    private javax.swing.JTextField Total;
    private javax.swing.JTextField ValorAdmon;
    private javax.swing.JTextField ValorCtasVnecidas;
    private javax.swing.JTextField ValorDescuentos;
    private javax.swing.JTextField ValorMultas;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
