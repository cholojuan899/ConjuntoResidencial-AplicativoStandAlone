package com.mycompany.Windows;

import java.io.FileWriter;
import java.io.IOException;
import com.opencsv.CSVWriter;


public class RegistrarEmpleados extends javax.swing.JFrame {

    
    
    public RegistrarEmpleados() {
    initComponents();  // Inicializa los componentes de la ventana
    setLocationRelativeTo(null);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        Titulo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Guardar = new javax.swing.JButton();
        Cancelar = new javax.swing.JButton();
        Salir1 = new javax.swing.JButton();
        Apellido = new javax.swing.JTextField();
        NumeroId = new javax.swing.JTextField();
        TipoDocumento = new javax.swing.JComboBox<>();
        Nacionalidad = new javax.swing.JTextField();
        Nombre = new javax.swing.JTextField();
        TelFijo = new javax.swing.JTextField();
        Celular = new javax.swing.JTextField();
        Contraseña = new javax.swing.JTextField();
        Cargo = new javax.swing.JTextField();
        Email = new javax.swing.JTextField();
        FechaInicio = new javax.swing.JTextField();
        Salario = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(92, 123, 105));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator1.setToolTipText("");
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 880, 10));

        Titulo.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Titulo.setForeground(new java.awt.Color(200, 215, 189));
        Titulo.setText("Registrar Empleados");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/LETRAS.png"))); // NOI18N
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 540, -1, 50));

        Guardar.setBackground(new java.awt.Color(159, 191, 166));
        Guardar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Guardar.setForeground(new java.awt.Color(0, 0, 0));
        Guardar.setText("Guardar");
        Guardar.setToolTipText("");
        Guardar.setBorderPainted(false);
        Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarActionPerformed(evt);
            }
        });
        jPanel1.add(Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 560, -1, -1));

        Cancelar.setBackground(new java.awt.Color(159, 191, 166));
        Cancelar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Cancelar.setForeground(new java.awt.Color(0, 0, 0));
        Cancelar.setText("Cancelar");
        Cancelar.setToolTipText("");
        Cancelar.setBorderPainted(false);
        Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarActionPerformed(evt);
            }
        });
        jPanel1.add(Cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 560, -1, -1));

        Salir1.setBackground(new java.awt.Color(159, 191, 166));
        Salir1.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Salir1.setForeground(new java.awt.Color(0, 0, 0));
        Salir1.setText("Atrás");
        Salir1.setToolTipText("");
        Salir1.setBorderPainted(false);
        Salir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Salir1ActionPerformed(evt);
            }
        });
        jPanel1.add(Salir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 10, -1, -1));

        Apellido.setBackground(new java.awt.Color(255, 255, 255));
        Apellido.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Apellido.setForeground(new java.awt.Color(153, 153, 153));
        Apellido.setText("Apellido");
        Apellido.setBorder(null);
        Apellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ApellidoActionPerformed(evt);
            }
        });
        jPanel1.add(Apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 70, 430, 30));

        NumeroId.setBackground(new java.awt.Color(255, 255, 255));
        NumeroId.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NumeroId.setForeground(new java.awt.Color(153, 153, 153));
        NumeroId.setText("Numero de Documento");
        NumeroId.setToolTipText("");
        NumeroId.setBorder(null);
        NumeroId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumeroIdActionPerformed(evt);
            }
        });
        jPanel1.add(NumeroId, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 120, 650, 30));

        TipoDocumento.setBackground(new java.awt.Color(255, 255, 255));
        TipoDocumento.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        TipoDocumento.setForeground(new java.awt.Color(0, 0, 0));
        TipoDocumento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tipo de Documento", "C.C", "C.E", "Pasaporte", "T.I", "NUI", "R.C" }));
        TipoDocumento.setBorder(null);
        TipoDocumento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoDocumentoActionPerformed(evt);
            }
        });
        jPanel1.add(TipoDocumento, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 220, 30));

        Nacionalidad.setBackground(new java.awt.Color(255, 255, 255));
        Nacionalidad.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Nacionalidad.setForeground(new java.awt.Color(153, 153, 153));
        Nacionalidad.setText("Nacionalidad");
        Nacionalidad.setBorder(null);
        Nacionalidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NacionalidadActionPerformed(evt);
            }
        });
        jPanel1.add(Nacionalidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 220, 430, 30));

        Nombre.setBackground(new java.awt.Color(255, 255, 255));
        Nombre.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Nombre.setForeground(new java.awt.Color(153, 153, 153));
        Nombre.setText("Nombre");
        Nombre.setBorder(null);
        Nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreActionPerformed(evt);
            }
        });
        jPanel1.add(Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 430, 30));

        TelFijo.setBackground(new java.awt.Color(255, 255, 255));
        TelFijo.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        TelFijo.setForeground(new java.awt.Color(153, 153, 153));
        TelFijo.setText("Telefono Fijo");
        TelFijo.setBorder(null);
        TelFijo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TelFijoActionPerformed(evt);
            }
        });
        jPanel1.add(TelFijo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 430, 30));

        Celular.setBackground(new java.awt.Color(255, 255, 255));
        Celular.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Celular.setForeground(new java.awt.Color(153, 153, 153));
        Celular.setText("Celular");
        Celular.setBorder(null);
        Celular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CelularActionPerformed(evt);
            }
        });
        jPanel1.add(Celular, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 170, 430, 30));

        Contraseña.setBackground(new java.awt.Color(255, 255, 255));
        Contraseña.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Contraseña.setForeground(new java.awt.Color(153, 153, 153));
        Contraseña.setText("Contraseña ");
        Contraseña.setBorder(null);
        Contraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContraseñaActionPerformed(evt);
            }
        });
        jPanel1.add(Contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 320, 340, 30));

        Cargo.setBackground(new java.awt.Color(255, 255, 255));
        Cargo.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Cargo.setForeground(new java.awt.Color(153, 153, 153));
        Cargo.setText("Cargo");
        Cargo.setBorder(null);
        Cargo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CargoActionPerformed(evt);
            }
        });
        jPanel1.add(Cargo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 430, 30));

        Email.setBackground(new java.awt.Color(255, 255, 255));
        Email.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Email.setForeground(new java.awt.Color(153, 153, 153));
        Email.setText("Email");
        Email.setBorder(null);
        Email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmailActionPerformed(evt);
            }
        });
        jPanel1.add(Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 880, 30));

        FechaInicio.setBackground(new java.awt.Color(255, 255, 255));
        FechaInicio.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        FechaInicio.setForeground(new java.awt.Color(153, 153, 153));
        FechaInicio.setText("Fecha de Inicio");
        FechaInicio.setBorder(null);
        FechaInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FechaInicioActionPerformed(evt);
            }
        });
        jPanel1.add(FechaInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, 260, 30));

        Salario.setBackground(new java.awt.Color(255, 255, 255));
        Salario.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Salario.setForeground(new java.awt.Color(153, 153, 153));
        Salario.setText("Salario");
        Salario.setBorder(null);
        Salario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalarioActionPerformed(evt);
            }
        });
        jPanel1.add(Salario, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 320, 260, 30));

        jLabel3.setFont(new java.awt.Font("Montserrat", 0, 12)); // NOI18N
        jLabel3.setText("La contraseña debe contener al menos 8 caracteres");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 350, -1, -1));

        jLabel1.setBackground(new java.awt.Color(204, 255, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/HOJA.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 900, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NumeroIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumeroIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumeroIdActionPerformed

    private void ApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ApellidoActionPerformed

    private void Salir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Salir1ActionPerformed
        MenuEmpleados mEmpleados = new MenuEmpleados();
        mEmpleados.setVisible(true);
        mEmpleados.setLocationRelativeTo(null);
        dispose();
    }//GEN-LAST:event_Salir1ActionPerformed

    private void CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CancelarActionPerformed

    private void GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarActionPerformed
        String filePath = "data/empleados.csv";
    
    // Datos a guardar en el CSV, obtenidos de los campos de texto
    String[] empleado = {
        Nombre.getText(),
        Apellido.getText(),
        NumeroId.getText(),
        (String) TipoDocumento.getSelectedItem(),
        Nacionalidad.getText(),
        TelFijo.getText(),
        Celular.getText(),
        Contraseña.getText(),
        Cargo.getText(),
        Email.getText(),
        FechaInicio.getText(),
        Salario.getText()
    };

    try (CSVWriter writer = new CSVWriter(new FileWriter(filePath, false))) {
        // Sobreescribe el archivo CSV con la nueva información
        writer.writeNext(new String[] {
            "Nombre", "Apellido", "Numero Documento", "Tipo Documento",
            "Nacionalidad", "Telefono Fijo", "Celular", "Contraseña",
            "Cargo", "Email", "Fecha Inicio", "Salario"
        });
        writer.writeNext(empleado);

        // Mensaje de confirmación
        javax.swing.JOptionPane.showMessageDialog(this, "Empleado guardado correctamente.");
    } catch (IOException e) {
        // Manejo de errores
        javax.swing.JOptionPane.showMessageDialog(this, "Error al guardar el empleado: " + e.getMessage());
    }
    }//GEN-LAST:event_GuardarActionPerformed

    private void TipoDocumentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoDocumentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TipoDocumentoActionPerformed

    private void NacionalidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NacionalidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NacionalidadActionPerformed

    private void NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreActionPerformed

    private void TelFijoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TelFijoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TelFijoActionPerformed

    private void CelularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CelularActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CelularActionPerformed

    private void ContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContraseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ContraseñaActionPerformed

    private void CargoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CargoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CargoActionPerformed

    private void EmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EmailActionPerformed

    private void FechaInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FechaInicioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FechaInicioActionPerformed

    private void SalarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SalarioActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Apellido;
    private javax.swing.JButton Cancelar;
    private javax.swing.JTextField Cargo;
    private javax.swing.JTextField Celular;
    private javax.swing.JTextField Contraseña;
    private javax.swing.JTextField Email;
    private javax.swing.JTextField FechaInicio;
    private javax.swing.JButton Guardar;
    private javax.swing.JTextField Nacionalidad;
    private javax.swing.JTextField Nombre;
    private javax.swing.JTextField NumeroId;
    private javax.swing.JTextField Salario;
    private javax.swing.JButton Salir1;
    private javax.swing.JTextField TelFijo;
    private javax.swing.JComboBox<String> TipoDocumento;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
