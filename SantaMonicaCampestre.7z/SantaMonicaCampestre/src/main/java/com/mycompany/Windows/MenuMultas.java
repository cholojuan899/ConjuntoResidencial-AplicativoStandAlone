package com.mycompany.Windows;


public class MenuMultas extends javax.swing.JFrame {

    public MenuMultas() {
    initComponents();  // Inicializa los componentes de la ventana
    setLocationRelativeTo(null);
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Bienvenido = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        Titulo = new javax.swing.JLabel();
        Salir = new javax.swing.JButton();
        CrearMulta = new javax.swing.JButton();
        Consulta = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(159, 191, 166));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Bienvenido.setFont(new java.awt.Font("Amaranth", 1, 56)); // NOI18N
        Bienvenido.setForeground(new java.awt.Color(0, 0, 0));
        Bienvenido.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Bienvenido.setText("Multas");
        Bienvenido.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel1.add(Bienvenido, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 900, -1));

        jSeparator1.setToolTipText("");
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 880, 10));

        Titulo.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Titulo.setForeground(new java.awt.Color(0, 51, 16));
        Titulo.setText("Santa Mónica Campestre");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        Salir.setBackground(new java.awt.Color(92, 123, 105));
        Salir.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Salir.setForeground(new java.awt.Color(0, 0, 0));
        Salir.setText("Atrás");
        Salir.setToolTipText("");
        Salir.setBorderPainted(false);
        Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirActionPerformed(evt);
            }
        });
        jPanel1.add(Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 10, -1, -1));

        CrearMulta.setBackground(new java.awt.Color(200, 215, 189));
        CrearMulta.setFont(new java.awt.Font("Montserrat", 1, 22)); // NOI18N
        CrearMulta.setForeground(new java.awt.Color(0, 0, 0));
        CrearMulta.setText("GENERAR MULTA");
        CrearMulta.setBorderPainted(false);
        CrearMulta.setContentAreaFilled(false);
        CrearMulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CrearMultaActionPerformed(evt);
            }
        });
        jPanel1.add(CrearMulta, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 290, 280, -1));

        Consulta.setBackground(new java.awt.Color(200, 215, 189));
        Consulta.setFont(new java.awt.Font("Montserrat", 1, 22)); // NOI18N
        Consulta.setForeground(new java.awt.Color(0, 0, 0));
        Consulta.setText("CONSULTA");
        Consulta.setToolTipText("");
        Consulta.setBorderPainted(false);
        Consulta.setContentAreaFilled(false);
        Consulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConsultaActionPerformed(evt);
            }
        });
        jPanel1.add(Consulta, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 290, -1, -1));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/LETRAS.png"))); // NOI18N
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 530, -1, 50));

        jLabel1.setBackground(new java.awt.Color(204, 255, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/HOJA.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 900, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirActionPerformed
        MenuPrincipal mPrincipal = new MenuPrincipal();
        mPrincipal .setVisible(true);
        mPrincipal .setLocationRelativeTo(null);
        dispose();
    }//GEN-LAST:event_SalirActionPerformed

    private void CrearMultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CrearMultaActionPerformed
        GenerarMulta gMulta  = new GenerarMulta ();
        gMulta.setVisible(true);
        gMulta.setLocationRelativeTo(null);
        dispose();
    }//GEN-LAST:event_CrearMultaActionPerformed

    private void ConsultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConsultaActionPerformed
        ConsultarMulta cMulta  = new ConsultarMulta ();
        cMulta.setVisible(true);
        cMulta.setLocationRelativeTo(null);
        dispose();
    }//GEN-LAST:event_ConsultaActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Bienvenido;
    private javax.swing.JButton Consulta;
    private javax.swing.JButton CrearMulta;
    private javax.swing.JButton Salir;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
