package com.mycompany.Windows;

import java.io.FileWriter;
import java.io.IOException;


public class RegistrarAreaComun extends javax.swing.JFrame {

    public RegistrarAreaComun() {
    initComponents();  // Inicializa los componentes de la ventana
    setLocationRelativeTo(null);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        Titulo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Guardar = new javax.swing.JButton();
        Cancelar = new javax.swing.JButton();
        Salir1 = new javax.swing.JButton();
        Cpacidad = new javax.swing.JTextField();
        NombreAreaComun = new javax.swing.JTextField();
        PiriodicidadMan = new javax.swing.JTextField();
        CostoMant = new javax.swing.JTextField();
        DiasServicio = new javax.swing.JTextField();
        HoraApertura = new javax.swing.JTextField();
        HoraCierre = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(92, 123, 105));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator1.setToolTipText("");
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 880, 10));

        Titulo.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Titulo.setForeground(new java.awt.Color(200, 215, 189));
        Titulo.setText("Registrar Área Común");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/LETRAS.png"))); // NOI18N
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 540, -1, 50));

        Guardar.setBackground(new java.awt.Color(159, 191, 166));
        Guardar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Guardar.setForeground(new java.awt.Color(0, 0, 0));
        Guardar.setText("Guardar");
        Guardar.setToolTipText("");
        Guardar.setBorderPainted(false);
        Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarActionPerformed(evt);
            }
        });
        jPanel1.add(Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 560, -1, -1));

        Cancelar.setBackground(new java.awt.Color(159, 191, 166));
        Cancelar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Cancelar.setForeground(new java.awt.Color(0, 0, 0));
        Cancelar.setText("Cancelar");
        Cancelar.setToolTipText("");
        Cancelar.setBorderPainted(false);
        Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarActionPerformed(evt);
            }
        });
        jPanel1.add(Cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 560, -1, -1));

        Salir1.setBackground(new java.awt.Color(159, 191, 166));
        Salir1.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Salir1.setForeground(new java.awt.Color(0, 0, 0));
        Salir1.setText("Atrás");
        Salir1.setToolTipText("");
        Salir1.setBorderPainted(false);
        Salir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Salir1ActionPerformed(evt);
            }
        });
        jPanel1.add(Salir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 10, -1, -1));

        Cpacidad.setBackground(new java.awt.Color(255, 255, 255));
        Cpacidad.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Cpacidad.setForeground(new java.awt.Color(153, 153, 153));
        Cpacidad.setText("Capacidad");
        Cpacidad.setToolTipText("");
        Cpacidad.setBorder(null);
        Cpacidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CpacidadActionPerformed(evt);
            }
        });
        jPanel1.add(Cpacidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 120, 280, 30));

        NombreAreaComun.setBackground(new java.awt.Color(255, 255, 255));
        NombreAreaComun.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NombreAreaComun.setForeground(new java.awt.Color(153, 153, 153));
        NombreAreaComun.setText("Nombre del Área Común");
        NombreAreaComun.setBorder(null);
        NombreAreaComun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreAreaComunActionPerformed(evt);
            }
        });
        jPanel1.add(NombreAreaComun, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 880, 30));

        PiriodicidadMan.setBackground(new java.awt.Color(255, 255, 255));
        PiriodicidadMan.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        PiriodicidadMan.setForeground(new java.awt.Color(153, 153, 153));
        PiriodicidadMan.setText("Peridicidad de Mantenimiento");
        PiriodicidadMan.setBorder(null);
        PiriodicidadMan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PiriodicidadManActionPerformed(evt);
            }
        });
        jPanel1.add(PiriodicidadMan, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 430, 30));

        CostoMant.setBackground(new java.awt.Color(255, 255, 255));
        CostoMant.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        CostoMant.setForeground(new java.awt.Color(153, 153, 153));
        CostoMant.setText("Costo Mantenimiento (c/u)");
        CostoMant.setBorder(null);
        CostoMant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CostoMantActionPerformed(evt);
            }
        });
        jPanel1.add(CostoMant, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 170, 430, 30));

        DiasServicio.setBackground(new java.awt.Color(255, 255, 255));
        DiasServicio.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        DiasServicio.setForeground(new java.awt.Color(153, 153, 153));
        DiasServicio.setText("Cantidad de Dias de Servicio");
        DiasServicio.setBorder(null);
        DiasServicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DiasServicioActionPerformed(evt);
            }
        });
        jPanel1.add(DiasServicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 430, 30));

        HoraApertura.setBackground(new java.awt.Color(255, 255, 255));
        HoraApertura.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        HoraApertura.setForeground(new java.awt.Color(153, 153, 153));
        HoraApertura.setText("Hora de Apertura");
        HoraApertura.setToolTipText("");
        HoraApertura.setBorder(null);
        HoraApertura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HoraAperturaActionPerformed(evt);
            }
        });
        jPanel1.add(HoraApertura, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 280, 30));

        HoraCierre.setBackground(new java.awt.Color(255, 255, 255));
        HoraCierre.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        HoraCierre.setForeground(new java.awt.Color(153, 153, 153));
        HoraCierre.setText("Hora de Cierre");
        HoraCierre.setToolTipText("");
        HoraCierre.setBorder(null);
        HoraCierre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HoraCierreActionPerformed(evt);
            }
        });
        jPanel1.add(HoraCierre, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 120, 280, 30));

        jLabel1.setBackground(new java.awt.Color(204, 255, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/HOJA.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 900, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CpacidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CpacidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CpacidadActionPerformed

    private void Salir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Salir1ActionPerformed
        MenuAreasComunes mAreasComunes = new MenuAreasComunes();
        mAreasComunes.setVisible(true);
        mAreasComunes.setLocationRelativeTo(null);
        dispose();
    }//GEN-LAST:event_Salir1ActionPerformed

    private void CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CancelarActionPerformed

    private void GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarActionPerformed
        String capacidad = Cpacidad.getText();
        String diasServicio = DiasServicio.getText();
        String nombreAreaComun = NombreAreaComun.getText();
        String costoMantenimiento = CostoMant.getText();
        String horaApertura = HoraApertura.getText();
        String horaCierre = HoraCierre.getText();
        String periodicidadMantenimiento = PiriodicidadMan.getText();
        
        // Ruta del archivo CSV en la carpeta data
        String filePath = "data/AreasComunes.csv";

        try (FileWriter writer = new FileWriter(filePath, false)) { // 'false' para sobrescribir el archivo
        // Escribir el encabezado
        writer.write("NombreAreaComun,CostoMantenimiento,HoraApertura,HoraCierre,PeriodicidadMantenimiento,diasServicio,Capacidad\n");

        // Escribir los datos
        writer.write(nombreAreaComun + "," + costoMantenimiento + "," + horaApertura + "," + horaCierre + "," + periodicidadMantenimiento + "," + diasServicio + "," + capacidad  + "\n");

        // Mensaje de éxito
        javax.swing.JOptionPane.showMessageDialog(this, "Datos guardados correctamente.");

        } catch (IOException e) {
        e.printStackTrace();
        javax.swing.JOptionPane.showMessageDialog(this, "Error al guardar los datos.");
        }
    }//GEN-LAST:event_GuardarActionPerformed

    private void NombreAreaComunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreAreaComunActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreAreaComunActionPerformed

    private void PiriodicidadManActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PiriodicidadManActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PiriodicidadManActionPerformed

    private void CostoMantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CostoMantActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CostoMantActionPerformed

    private void DiasServicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DiasServicioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DiasServicioActionPerformed

    private void HoraAperturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HoraAperturaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_HoraAperturaActionPerformed

    private void HoraCierreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HoraCierreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_HoraCierreActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cancelar;
    private javax.swing.JTextField CostoMant;
    private javax.swing.JTextField Cpacidad;
    private javax.swing.JTextField DiasServicio;
    private javax.swing.JButton Guardar;
    private javax.swing.JTextField HoraApertura;
    private javax.swing.JTextField HoraCierre;
    private javax.swing.JTextField NombreAreaComun;
    private javax.swing.JTextField PiriodicidadMan;
    private javax.swing.JButton Salir1;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
