package com.mycompany.Windows;

import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;


public class GenerarMulta extends javax.swing.JFrame {

    public GenerarMulta() {
    initComponents();  // Inicializa los componentes de la ventana
    setLocationRelativeTo(null);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        Titulo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Generar = new javax.swing.JButton();
        Cancelar = new javax.swing.JButton();
        Apellido = new javax.swing.JTextField();
        NumeroId = new javax.swing.JTextField();
        ValorMulta = new javax.swing.JTextField();
        Nombre = new javax.swing.JTextField();
        NumPropiedad = new javax.swing.JTextField();
        LugarOcurrencia = new javax.swing.JTextField();
        Contraseña = new javax.swing.JTextField();
        FechaReporte = new javax.swing.JTextField();
        TipoDocumento1 = new javax.swing.JComboBox<>();
        NumMulta = new javax.swing.JTextField();
        FechaMaximaPago = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        Observaciones = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        EventoOcurrido = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        Salir1 = new javax.swing.JButton();
        Guardar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(159, 191, 166));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator1.setToolTipText("");
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 880, 10));

        Titulo.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Titulo.setForeground(new java.awt.Color(0, 51, 16));
        Titulo.setText("Generar Multa");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/LETRAS.png"))); // NOI18N
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 540, -1, 50));

        Generar.setBackground(new java.awt.Color(165, 159, 191));
        Generar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Generar.setForeground(new java.awt.Color(0, 0, 0));
        Generar.setText(" Generar JSON");
        Generar.setToolTipText("");
        Generar.setBorderPainted(false);
        Generar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Generar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GenerarActionPerformed(evt);
            }
        });
        jPanel1.add(Generar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 550, -1, -1));

        Cancelar.setBackground(new java.awt.Color(92, 123, 105));
        Cancelar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Cancelar.setForeground(new java.awt.Color(0, 0, 0));
        Cancelar.setText("Cancelar");
        Cancelar.setToolTipText("");
        Cancelar.setBorderPainted(false);
        Cancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarActionPerformed(evt);
            }
        });
        jPanel1.add(Cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 550, -1, -1));

        Apellido.setBackground(new java.awt.Color(255, 255, 255));
        Apellido.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Apellido.setForeground(new java.awt.Color(153, 153, 153));
        Apellido.setText("Apellido");
        Apellido.setBorder(null);
        Apellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ApellidoActionPerformed(evt);
            }
        });
        jPanel1.add(Apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 70, 430, 30));

        NumeroId.setBackground(new java.awt.Color(255, 255, 255));
        NumeroId.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NumeroId.setForeground(new java.awt.Color(153, 153, 153));
        NumeroId.setText("Numero de Documento");
        NumeroId.setToolTipText("");
        NumeroId.setBorder(null);
        NumeroId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumeroIdActionPerformed(evt);
            }
        });
        jPanel1.add(NumeroId, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 120, 650, 30));

        ValorMulta.setBackground(new java.awt.Color(255, 255, 255));
        ValorMulta.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        ValorMulta.setForeground(new java.awt.Color(153, 153, 153));
        ValorMulta.setText("Valor de la Multa");
        ValorMulta.setBorder(null);
        ValorMulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ValorMultaActionPerformed(evt);
            }
        });
        jPanel1.add(ValorMulta, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 220, 280, 30));

        Nombre.setBackground(new java.awt.Color(255, 255, 255));
        Nombre.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Nombre.setForeground(new java.awt.Color(153, 153, 153));
        Nombre.setText("Nombre");
        Nombre.setBorder(null);
        Nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreActionPerformed(evt);
            }
        });
        jPanel1.add(Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 430, 30));

        NumPropiedad.setBackground(new java.awt.Color(255, 255, 255));
        NumPropiedad.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NumPropiedad.setForeground(new java.awt.Color(153, 153, 153));
        NumPropiedad.setText("Numero de Propiedad");
        NumPropiedad.setBorder(null);
        NumPropiedad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumPropiedadActionPerformed(evt);
            }
        });
        jPanel1.add(NumPropiedad, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 430, 30));

        LugarOcurrencia.setBackground(new java.awt.Color(255, 255, 255));
        LugarOcurrencia.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        LugarOcurrencia.setForeground(new java.awt.Color(153, 153, 153));
        LugarOcurrencia.setText("Lugar de Ocurrencia");
        LugarOcurrencia.setBorder(null);
        LugarOcurrencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LugarOcurrenciaActionPerformed(evt);
            }
        });
        jPanel1.add(LugarOcurrencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 170, 430, 30));

        Contraseña.setBackground(new java.awt.Color(255, 255, 255));
        Contraseña.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Contraseña.setForeground(new java.awt.Color(153, 153, 153));
        Contraseña.setText("Fecha del Evento");
        Contraseña.setToolTipText("");
        Contraseña.setBorder(null);
        Contraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContraseñaActionPerformed(evt);
            }
        });
        jPanel1.add(Contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 450, 430, 30));

        FechaReporte.setBackground(new java.awt.Color(255, 255, 255));
        FechaReporte.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        FechaReporte.setForeground(new java.awt.Color(153, 153, 153));
        FechaReporte.setText("Fecha del Reporte");
        FechaReporte.setBorder(null);
        FechaReporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FechaReporteActionPerformed(evt);
            }
        });
        jPanel1.add(FechaReporte, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 450, 430, 30));

        TipoDocumento1.setBackground(new java.awt.Color(255, 255, 255));
        TipoDocumento1.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        TipoDocumento1.setForeground(new java.awt.Color(0, 0, 0));
        TipoDocumento1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tipo de Documento", "C.C", "C.E", "Pasaporte", "T.I", "NUI", "R.C" }));
        TipoDocumento1.setBorder(null);
        TipoDocumento1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoDocumento1ActionPerformed(evt);
            }
        });
        jPanel1.add(TipoDocumento1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 220, 30));

        NumMulta.setBackground(new java.awt.Color(255, 255, 255));
        NumMulta.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NumMulta.setForeground(new java.awt.Color(153, 153, 153));
        NumMulta.setText("Numero de la Multa");
        NumMulta.setBorder(null);
        NumMulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumMultaActionPerformed(evt);
            }
        });
        jPanel1.add(NumMulta, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 280, 30));

        FechaMaximaPago.setBackground(new java.awt.Color(255, 255, 255));
        FechaMaximaPago.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        FechaMaximaPago.setForeground(new java.awt.Color(153, 153, 153));
        FechaMaximaPago.setText("Fecha Maxima de Pago");
        FechaMaximaPago.setBorder(null);
        FechaMaximaPago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FechaMaximaPagoActionPerformed(evt);
            }
        });
        jPanel1.add(FechaMaximaPago, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 220, 280, 30));

        jScrollPane1.setBorder(null);

        Observaciones.setBackground(new java.awt.Color(255, 255, 255));
        Observaciones.setColumns(20);
        Observaciones.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Observaciones.setForeground(new java.awt.Color(153, 153, 153));
        Observaciones.setLineWrap(true);
        Observaciones.setRows(5);
        Observaciones.setText("Observaciones y Prueba");
        Observaciones.setBorder(null);
        jScrollPane1.setViewportView(Observaciones);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 260, 430, 170));

        jScrollPane2.setBorder(null);

        EventoOcurrido.setBackground(new java.awt.Color(255, 255, 255));
        EventoOcurrido.setColumns(20);
        EventoOcurrido.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        EventoOcurrido.setForeground(new java.awt.Color(153, 153, 153));
        EventoOcurrido.setLineWrap(true);
        EventoOcurrido.setRows(5);
        EventoOcurrido.setText("Evento Ocurrido");
        jScrollPane2.setViewportView(EventoOcurrido);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 430, 170));

        jLabel1.setBackground(new java.awt.Color(204, 255, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/HOJA.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 900, -1));

        Salir1.setBackground(new java.awt.Color(92, 123, 105));
        Salir1.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Salir1.setForeground(new java.awt.Color(0, 0, 0));
        Salir1.setText("Atrás");
        Salir1.setToolTipText("");
        Salir1.setBorderPainted(false);
        Salir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Salir1ActionPerformed(evt);
            }
        });
        jPanel1.add(Salir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 10, -1, -1));

        Guardar.setBackground(new java.awt.Color(92, 123, 105));
        Guardar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Guardar.setForeground(new java.awt.Color(0, 0, 0));
        Guardar.setText("Guardar");
        Guardar.setToolTipText("");
        Guardar.setBorderPainted(false);
        Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarActionPerformed(evt);
            }
        });
        jPanel1.add(Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 550, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NumeroIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumeroIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumeroIdActionPerformed

    private void ApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ApellidoActionPerformed

    private void CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CancelarActionPerformed

    private void GenerarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GenerarActionPerformed
    org.json.JSONObject json = new org.json.JSONObject();
    
    // Collect data from the fields
    json.put("Nombre", Nombre.getText());
    json.put("Apellido", Apellido.getText());
    json.put("NumeroId", NumeroId.getText());
    json.put("TipoDocumento", TipoDocumento1.getSelectedItem().toString());
    json.put("TelFijo", NumPropiedad.getText());
    json.put("LugarOcurrencia", LugarOcurrencia.getText());
    json.put("FechaEvento", Contraseña.getText());
    json.put("FechaReporte", FechaReporte.getText());
    json.put("NumMulta", NumMulta.getText());
    json.put("ValorMulta", ValorMulta.getText());
    json.put("FechaMaximaPago", FechaMaximaPago.getText());
    json.put("EventoOcurrido", EventoOcurrido.getText());
    json.put("Observaciones", Observaciones.getText());

    // Define the file path
    String filePath = "multa.json"; // You can change the path as needed

    // Write JSON to a file
    try (FileWriter file = new FileWriter(filePath)) {
        file.write(json.toString(4)); // Indent with 4 spaces
        file.flush();
        JOptionPane.showMessageDialog(this, "JSON file generated successfully at " + filePath);
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error writing JSON file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_GenerarActionPerformed

    private void ValorMultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ValorMultaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ValorMultaActionPerformed

    private void NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreActionPerformed

    private void NumPropiedadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumPropiedadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumPropiedadActionPerformed

    private void LugarOcurrenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LugarOcurrenciaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_LugarOcurrenciaActionPerformed

    private void ContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContraseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ContraseñaActionPerformed

    private void FechaReporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FechaReporteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FechaReporteActionPerformed

    private void TipoDocumento1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoDocumento1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TipoDocumento1ActionPerformed

    private void NumMultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumMultaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumMultaActionPerformed

    private void FechaMaximaPagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FechaMaximaPagoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FechaMaximaPagoActionPerformed

    private void Salir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Salir1ActionPerformed
        MenuMultas mMultas = new MenuMultas();
        mMultas.setVisible(true);
        mMultas.setLocationRelativeTo(null);
        dispose();
    }//GEN-LAST:event_Salir1ActionPerformed

    private void GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarActionPerformed
        
    }//GEN-LAST:event_GuardarActionPerformed
 
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Apellido;
    private javax.swing.JButton Cancelar;
    private javax.swing.JTextField Contraseña;
    private javax.swing.JTextArea EventoOcurrido;
    private javax.swing.JTextField FechaMaximaPago;
    private javax.swing.JTextField FechaReporte;
    private javax.swing.JButton Generar;
    private javax.swing.JButton Guardar;
    private javax.swing.JTextField LugarOcurrencia;
    private javax.swing.JTextField Nombre;
    private javax.swing.JTextField NumMulta;
    private javax.swing.JTextField NumPropiedad;
    private javax.swing.JTextField NumeroId;
    private javax.swing.JTextArea Observaciones;
    private javax.swing.JButton Salir1;
    private javax.swing.JComboBox<String> TipoDocumento1;
    private javax.swing.JLabel Titulo;
    private javax.swing.JTextField ValorMulta;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
