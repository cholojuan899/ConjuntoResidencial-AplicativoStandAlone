package com.mycompany.Windows;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;



public class CalificarEmpleados extends javax.swing.JFrame {

    public CalificarEmpleados() {
    initComponents();  // Inicializa los componentes de la ventana
    setLocationRelativeTo(null);
    pack();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        Titulo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Cancelar = new javax.swing.JButton();
        Salir1 = new javax.swing.JButton();
        NumeroId = new javax.swing.JTextField();
        Calificacion = new javax.swing.JTextField();
        Observaciones = new javax.swing.JTextField();
        Guardar1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(900, 600));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(92, 123, 105));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator1.setToolTipText("");
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 880, 10));

        Titulo.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Titulo.setForeground(new java.awt.Color(200, 215, 189));
        Titulo.setText("Calificar Empleados");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/LETRAS.png"))); // NOI18N
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 510, -1, 50));

        Cancelar.setBackground(new java.awt.Color(159, 191, 166));
        Cancelar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Cancelar.setForeground(new java.awt.Color(0, 0, 0));
        Cancelar.setText("Cancelar");
        Cancelar.setToolTipText("");
        Cancelar.setBorderPainted(false);
        Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarActionPerformed(evt);
            }
        });
        jPanel1.add(Cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 530, -1, -1));

        Salir1.setBackground(new java.awt.Color(159, 191, 166));
        Salir1.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Salir1.setForeground(new java.awt.Color(0, 0, 0));
        Salir1.setText("Atrás");
        Salir1.setToolTipText("");
        Salir1.setBorderPainted(false);
        Salir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Salir1ActionPerformed(evt);
            }
        });
        jPanel1.add(Salir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 10, -1, -1));

        NumeroId.setBackground(new java.awt.Color(255, 255, 255));
        NumeroId.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NumeroId.setForeground(new java.awt.Color(153, 153, 153));
        NumeroId.setText("Numero de Documento");
        NumeroId.setToolTipText("");
        NumeroId.setBorder(null);
        NumeroId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumeroIdActionPerformed(evt);
            }
        });
        jPanel1.add(NumeroId, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 650, 30));

        Calificacion.setBackground(new java.awt.Color(255, 255, 255));
        Calificacion.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Calificacion.setForeground(new java.awt.Color(153, 153, 153));
        Calificacion.setText("Calificación");
        Calificacion.setBorder(null);
        Calificacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CalificacionActionPerformed(evt);
            }
        });
        jPanel1.add(Calificacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 430, 30));

        Observaciones.setBackground(new java.awt.Color(255, 255, 255));
        Observaciones.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Observaciones.setForeground(new java.awt.Color(153, 153, 153));
        Observaciones.setText("Observaciones");
        Observaciones.setBorder(null);
        Observaciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ObservacionesActionPerformed(evt);
            }
        });
        jPanel1.add(Observaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 430, 210));

        Guardar1.setBackground(new java.awt.Color(159, 191, 166));
        Guardar1.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Guardar1.setForeground(new java.awt.Color(0, 0, 0));
        Guardar1.setText("Guardar");
        Guardar1.setToolTipText("");
        Guardar1.setBorderPainted(false);
        Guardar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Guardar1ActionPerformed(evt);
            }
        });
        jPanel1.add(Guardar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 530, -1, -1));

        jLabel1.setBackground(new java.awt.Color(204, 255, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/HOJA.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 900, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NumeroIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumeroIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumeroIdActionPerformed

    private void Salir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Salir1ActionPerformed
        MenuEmpleados mEmpleados = new MenuEmpleados();
        mEmpleados.setVisible(true);
        mEmpleados.setLocationRelativeTo(null);
        pack();
        dispose();
    }//GEN-LAST:event_Salir1ActionPerformed

    private void CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarActionPerformed
    Calificacion.setText("Calificación"); 
    NumeroId.setText("Numero de Documento"); 
    Observaciones.setText("Observaciones"); 
    
    }//GEN-LAST:event_CancelarActionPerformed

    private void CalificacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CalificacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CalificacionActionPerformed

    private void ObservacionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ObservacionesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ObservacionesActionPerformed

    private void Guardar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Guardar1ActionPerformed
    // Obtener los datos de los campos de texto
    String nombre = Calificacion.getText();
    String numeroId = NumeroId.getText();
    String observaciones = Observaciones.getText();
   
    // Ruta del archivo CSV
    String archivoCSV = "data/calificaionEmpleados.csv";

    String lineaCSV = String.join(",", nombre, numeroId, observaciones);

    // Escribir en el archivo CSV
    try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivoCSV))) {
        bw.write(lineaCSV);
        bw.newLine();
        System.out.println("Datos guardados en " + archivoCSV);
    } catch (IOException e) {
        e.printStackTrace();
    }
    }//GEN-LAST:event_Guardar1ActionPerformed
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Calificacion;
    private javax.swing.JButton Cancelar;
    private javax.swing.JButton Guardar1;
    private javax.swing.JTextField NumeroId;
    private javax.swing.JTextField Observaciones;
    private javax.swing.JButton Salir1;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
