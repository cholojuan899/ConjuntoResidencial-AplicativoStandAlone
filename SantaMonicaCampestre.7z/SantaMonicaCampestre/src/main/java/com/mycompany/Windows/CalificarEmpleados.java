package com.mycompany.Windows;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;


public class CalificarEmpleados extends javax.swing.JFrame {

    public CalificarEmpleados() {
    initComponents();  // Inicializa los componentes de la ventana
    setLocationRelativeTo(null);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        Titulo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Guardar = new javax.swing.JButton();
        Cancelar = new javax.swing.JButton();
        Salir1 = new javax.swing.JButton();
        NumeroId = new javax.swing.JTextField();
        Calificacion = new javax.swing.JTextField();
        Observaciones = new javax.swing.JTextField();
        Guardar1 = new javax.swing.JButton();
        Buscar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(92, 123, 105));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator1.setToolTipText("");
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 880, 10));

        Titulo.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Titulo.setForeground(new java.awt.Color(200, 215, 189));
        Titulo.setText("Calificar Empleados");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/LETRAS.png"))); // NOI18N
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 530, -1, 50));

        Guardar.setBackground(new java.awt.Color(165, 159, 191));
        Guardar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Guardar.setForeground(new java.awt.Color(0, 0, 0));
        Guardar.setText("Calificar");
        Guardar.setToolTipText("");
        Guardar.setBorderPainted(false);
        Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarActionPerformed(evt);
            }
        });
        jPanel1.add(Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 550, -1, -1));

        Cancelar.setBackground(new java.awt.Color(159, 191, 166));
        Cancelar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Cancelar.setForeground(new java.awt.Color(0, 0, 0));
        Cancelar.setText("Cancelar");
        Cancelar.setToolTipText("");
        Cancelar.setBorderPainted(false);
        Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarActionPerformed(evt);
            }
        });
        jPanel1.add(Cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 550, -1, -1));

        Salir1.setBackground(new java.awt.Color(159, 191, 166));
        Salir1.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Salir1.setForeground(new java.awt.Color(0, 0, 0));
        Salir1.setText("Atrás");
        Salir1.setToolTipText("");
        Salir1.setBorderPainted(false);
        Salir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Salir1ActionPerformed(evt);
            }
        });
        jPanel1.add(Salir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(839, 10, -1, -1));

        NumeroId.setBackground(new java.awt.Color(255, 255, 255));
        NumeroId.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NumeroId.setForeground(new java.awt.Color(153, 153, 153));
        NumeroId.setText("Numero de Documento");
        NumeroId.setToolTipText("");
        NumeroId.setBorder(null);
        NumeroId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumeroIdActionPerformed(evt);
            }
        });
        jPanel1.add(NumeroId, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 650, 30));

        Calificacion.setBackground(new java.awt.Color(255, 255, 255));
        Calificacion.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Calificacion.setForeground(new java.awt.Color(153, 153, 153));
        Calificacion.setText("Calificación");
        Calificacion.setBorder(null);
        Calificacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CalificacionActionPerformed(evt);
            }
        });
        jPanel1.add(Calificacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 430, 30));

        Observaciones.setBackground(new java.awt.Color(255, 255, 255));
        Observaciones.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Observaciones.setForeground(new java.awt.Color(153, 153, 153));
        Observaciones.setText("Observaciones");
        Observaciones.setBorder(null);
        Observaciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ObservacionesActionPerformed(evt);
            }
        });
        jPanel1.add(Observaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 430, 210));

        Guardar1.setBackground(new java.awt.Color(159, 191, 166));
        Guardar1.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Guardar1.setForeground(new java.awt.Color(0, 0, 0));
        Guardar1.setText("Guardar");
        Guardar1.setToolTipText("");
        Guardar1.setBorderPainted(false);
        Guardar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Guardar1ActionPerformed(evt);
            }
        });
        jPanel1.add(Guardar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 550, -1, -1));

        Buscar.setBackground(new java.awt.Color(165, 159, 191));
        Buscar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Buscar.setForeground(new java.awt.Color(0, 0, 0));
        Buscar.setText("Buscar");
        Buscar.setToolTipText("");
        Buscar.setBorderPainted(false);
        Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarActionPerformed(evt);
            }
        });
        jPanel1.add(Buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 60, -1, -1));

        jLabel1.setBackground(new java.awt.Color(204, 255, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/HOJA.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 900, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NumeroIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumeroIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumeroIdActionPerformed

    private void Salir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Salir1ActionPerformed
        MenuEmpleados mEmpleados = new MenuEmpleados();
        mEmpleados.setVisible(true);
        mEmpleados.setLocationRelativeTo(null);
        dispose();
    }//GEN-LAST:event_Salir1ActionPerformed

    private void CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarActionPerformed
    Calificacion.setText(""); // Limpiar el campo de calificación
    NumeroId.setText(""); // Limpiar el campo de número de identificación
    Observaciones.setText(""); // Limpiar el campo de observaciones
    
    }//GEN-LAST:event_CancelarActionPerformed

    private void GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_GuardarActionPerformed

    private void CalificacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CalificacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CalificacionActionPerformed

    private void ObservacionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ObservacionesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ObservacionesActionPerformed

    private void Guardar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Guardar1ActionPerformed
        // Obtener los datos de los campos de texto
    String nombre = Calificacion.getText();
    String numeroId = NumeroId.getText();
    String observaciones = Observaciones.getText();
    
    
    // Ruta del archivo CSV
    String archivoCSV = "empleados.csv";

    // Crear una línea de datos para el CSV
    String lineaCSV = String.join(",", nombre, numeroId, observaciones);

    // Escribir en el archivo CSV
    try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivoCSV))) {
        bw.write(lineaCSV);
        bw.newLine(); // Agregar nueva línea
        System.out.println("Datos guardados en " + archivoCSV);
    } catch (IOException e) {
        e.printStackTrace(); // Manejo de errores
    }
    }//GEN-LAST:event_Guardar1ActionPerformed

    private void BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarActionPerformed
          String numeroId = NumeroId.getText();
    String filePath = "empleados.csv"; // Cambia esto a la ruta de tu archivo CSV

    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
        String line;
        boolean found = false;

        while ((line = br.readLine()) != null) {
            String[] data = line.split(","); // Asumiendo que el archivo CSV usa ',' como separador
            
            if (data[1].equals(numeroId)) { // Asumiendo que el Número de ID está en la segunda columna
                // Llenar los campos con los datos del archivo
                Calificacion.setText(data[0]); // Suponiendo que el nombre está en la primera columna
                Observaciones.setText(data[8]); // Cargo en la novena columna
                found = true;
                break;
            }
        }

        if (!found) {
            JOptionPane.showMessageDialog(this, "Empleado no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error al leer el archivo: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_BuscarActionPerformed
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Buscar;
    private javax.swing.JTextField Calificacion;
    private javax.swing.JButton Cancelar;
    private javax.swing.JButton Guardar;
    private javax.swing.JButton Guardar1;
    private javax.swing.JTextField NumeroId;
    private javax.swing.JTextField Observaciones;
    private javax.swing.JButton Salir1;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
