package com.mycompany.Windows;

import com.mycompany.Utilidades.FacturaPDF;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;


public class ConsultarFactura extends javax.swing.JFrame {
    
    public ConsultarFactura() {
    initComponents();  // Inicializa los componentes de la ventana
    setLocationRelativeTo(null);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        Titulo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Buscar = new javax.swing.JButton();
        Salir1 = new javax.swing.JButton();
        NumeroId = new javax.swing.JTextField();
        CtasVencidas = new javax.swing.JComboBox<>();
        Nacionalidad = new javax.swing.JTextField();
        NumPropiedad = new javax.swing.JTextField();
        ValorAdmon = new javax.swing.JTextField();
        Total = new javax.swing.JTextField();
        NumeroFactura = new javax.swing.JTextField();
        Fecha = new javax.swing.JTextField();
        TipoDocumento1 = new javax.swing.JComboBox<>();
        Descuentos = new javax.swing.JComboBox<>();
        Nacionalidad1 = new javax.swing.JTextField();
        Multas = new javax.swing.JComboBox<>();
        Nacionalidad2 = new javax.swing.JTextField();
        Generar = new javax.swing.JButton();
        Nombre = new javax.swing.JTextField();
        Apellido = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        Cancelar1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(159, 191, 166));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator1.setToolTipText("");
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 880, 10));

        Titulo.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Titulo.setForeground(new java.awt.Color(0, 51, 16));
        Titulo.setText("Conultar Factura");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/LETRAS.png"))); // NOI18N
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 540, -1, 50));

        Buscar.setBackground(new java.awt.Color(165, 159, 191));
        Buscar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Buscar.setForeground(new java.awt.Color(0, 0, 0));
        Buscar.setText("Buscar");
        Buscar.setToolTipText("");
        Buscar.setBorderPainted(false);
        Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarActionPerformed(evt);
            }
        });
        jPanel1.add(Buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 70, -1, -1));

        Salir1.setBackground(new java.awt.Color(92, 123, 105));
        Salir1.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Salir1.setForeground(new java.awt.Color(0, 0, 0));
        Salir1.setText("Atrás");
        Salir1.setToolTipText("");
        Salir1.setBorderPainted(false);
        Salir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Salir1ActionPerformed(evt);
            }
        });
        jPanel1.add(Salir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 10, -1, -1));

        NumeroId.setBackground(new java.awt.Color(255, 255, 255));
        NumeroId.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NumeroId.setForeground(new java.awt.Color(153, 153, 153));
        NumeroId.setText("Numero de Documento");
        NumeroId.setToolTipText("");
        NumeroId.setBorder(null);
        NumeroId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumeroIdActionPerformed(evt);
            }
        });
        jPanel1.add(NumeroId, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 160, 650, 30));

        CtasVencidas.setBackground(new java.awt.Color(255, 255, 255));
        CtasVencidas.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        CtasVencidas.setForeground(new java.awt.Color(0, 0, 0));
        CtasVencidas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ctas Vencidas", "Si", "No" }));
        CtasVencidas.setBorder(null);
        CtasVencidas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CtasVencidasActionPerformed(evt);
            }
        });
        jPanel1.add(CtasVencidas, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 260, 140, 30));

        Nacionalidad.setBackground(new java.awt.Color(255, 255, 255));
        Nacionalidad.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Nacionalidad.setForeground(new java.awt.Color(153, 153, 153));
        Nacionalidad.setText("Valor Ctas Vencidas");
        Nacionalidad.setBorder(null);
        Nacionalidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NacionalidadActionPerformed(evt);
            }
        });
        jPanel1.add(Nacionalidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 260, 280, 30));

        NumPropiedad.setBackground(new java.awt.Color(255, 255, 255));
        NumPropiedad.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NumPropiedad.setForeground(new java.awt.Color(153, 153, 153));
        NumPropiedad.setText("Numero de Propiedad");
        NumPropiedad.setBorder(null);
        NumPropiedad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumPropiedadActionPerformed(evt);
            }
        });
        jPanel1.add(NumPropiedad, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 430, 30));

        ValorAdmon.setBackground(new java.awt.Color(255, 255, 255));
        ValorAdmon.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        ValorAdmon.setForeground(new java.awt.Color(153, 153, 153));
        ValorAdmon.setText("Valor Administración");
        ValorAdmon.setBorder(null);
        ValorAdmon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ValorAdmonActionPerformed(evt);
            }
        });
        jPanel1.add(ValorAdmon, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 210, 430, 30));

        Total.setBackground(new java.awt.Color(255, 255, 255));
        Total.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Total.setForeground(new java.awt.Color(153, 153, 153));
        Total.setText("Total");
        Total.setBorder(null);
        Total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TotalActionPerformed(evt);
            }
        });
        jPanel1.add(Total, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 360, 420, 30));

        NumeroFactura.setBackground(new java.awt.Color(255, 255, 255));
        NumeroFactura.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NumeroFactura.setForeground(new java.awt.Color(153, 153, 153));
        NumeroFactura.setText("Numero de Factura");
        NumeroFactura.setBorder(null);
        NumeroFactura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumeroFacturaActionPerformed(evt);
            }
        });
        jPanel1.add(NumeroFactura, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 430, 30));

        Fecha.setBackground(new java.awt.Color(255, 255, 255));
        Fecha.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Fecha.setForeground(new java.awt.Color(153, 153, 153));
        Fecha.setText("Fecha");
        Fecha.setBorder(null);
        Fecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FechaActionPerformed(evt);
            }
        });
        jPanel1.add(Fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 430, 30));

        TipoDocumento1.setBackground(new java.awt.Color(255, 255, 255));
        TipoDocumento1.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        TipoDocumento1.setForeground(new java.awt.Color(0, 0, 0));
        TipoDocumento1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tipo de Documento", "C.C", "C.E", "Pasaporte", "T.I", "NUI", "R.C" }));
        TipoDocumento1.setBorder(null);
        TipoDocumento1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoDocumento1ActionPerformed(evt);
            }
        });
        jPanel1.add(TipoDocumento1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 220, 30));

        Descuentos.setBackground(new java.awt.Color(255, 255, 255));
        Descuentos.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Descuentos.setForeground(new java.awt.Color(0, 0, 0));
        Descuentos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Descuentos", "Si", "No" }));
        Descuentos.setBorder(null);
        Descuentos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DescuentosActionPerformed(evt);
            }
        });
        jPanel1.add(Descuentos, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 140, 30));

        Nacionalidad1.setBackground(new java.awt.Color(255, 255, 255));
        Nacionalidad1.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Nacionalidad1.setForeground(new java.awt.Color(153, 153, 153));
        Nacionalidad1.setText("Valor Descuentos");
        Nacionalidad1.setBorder(null);
        Nacionalidad1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Nacionalidad1ActionPerformed(evt);
            }
        });
        jPanel1.add(Nacionalidad1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 310, 280, 30));

        Multas.setBackground(new java.awt.Color(255, 255, 255));
        Multas.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Multas.setForeground(new java.awt.Color(0, 0, 0));
        Multas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Multas", "Si", "No" }));
        Multas.setBorder(null);
        Multas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MultasActionPerformed(evt);
            }
        });
        jPanel1.add(Multas, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 140, 30));

        Nacionalidad2.setBackground(new java.awt.Color(255, 255, 255));
        Nacionalidad2.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Nacionalidad2.setForeground(new java.awt.Color(153, 153, 153));
        Nacionalidad2.setText("Valor Multas");
        Nacionalidad2.setBorder(null);
        Nacionalidad2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Nacionalidad2ActionPerformed(evt);
            }
        });
        jPanel1.add(Nacionalidad2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, 280, 30));

        Generar.setBackground(new java.awt.Color(165, 159, 191));
        Generar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Generar.setForeground(new java.awt.Color(0, 0, 0));
        Generar.setText("Generar Recibo");
        Generar.setToolTipText("");
        Generar.setBorderPainted(false);
        Generar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GenerarActionPerformed(evt);
            }
        });
        jPanel1.add(Generar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 550, -1, -1));

        Nombre.setBackground(new java.awt.Color(255, 255, 255));
        Nombre.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Nombre.setForeground(new java.awt.Color(153, 153, 153));
        Nombre.setText("Nombre");
        Nombre.setBorder(null);
        Nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreActionPerformed(evt);
            }
        });
        jPanel1.add(Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 410, 430, 30));

        Apellido.setBackground(new java.awt.Color(255, 255, 255));
        Apellido.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Apellido.setForeground(new java.awt.Color(153, 153, 153));
        Apellido.setText("Apellido");
        Apellido.setBorder(null);
        Apellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ApellidoActionPerformed(evt);
            }
        });
        jPanel1.add(Apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 410, 430, 30));

        jLabel1.setBackground(new java.awt.Color(204, 255, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/HOJA.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 900, -1));

        Cancelar1.setBackground(new java.awt.Color(92, 123, 105));
        Cancelar1.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Cancelar1.setForeground(new java.awt.Color(0, 0, 0));
        Cancelar1.setText("Cancelar");
        Cancelar1.setToolTipText("");
        Cancelar1.setBorderPainted(false);
        Cancelar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Cancelar1ActionPerformed(evt);
            }
        });
        jPanel1.add(Cancelar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 550, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NumeroIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumeroIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumeroIdActionPerformed

    private void Salir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Salir1ActionPerformed
        MenuFacturacion mFacturacion = new MenuFacturacion();
        mFacturacion.setVisible(true);
        mFacturacion.setLocationRelativeTo(null);
        dispose();
    }//GEN-LAST:event_Salir1ActionPerformed

    private void BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarActionPerformed
                String numeroFacturaBuscar = NumeroFactura.getText().trim();
        
        if (numeroFacturaBuscar.isEmpty() || numeroFacturaBuscar.equals("Numero de Factura")) {
            JOptionPane.showMessageDialog(this, 
                "Por favor ingrese un número de factura válido", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        buscarFacturaEnCSV(numeroFacturaBuscar);
    }
    
    private void buscarFacturaEnCSV(String numeroFactura) {
        String csvFile = "facturas.csv";
        String line;
        boolean facturaEncontrada = false;
        
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            // Leer la primera línea (encabezados)
            String headerLine = br.readLine();
            
            while ((line = br.readLine()) != null) {
                String[] datos = line.split(",");
                
                // Asumiendo que el número de factura es la primera columna
                if (datos[0].equals(numeroFactura)) {
                    // Cargar los datos en los campos
                    cargarDatosEnCampos(datos);
                    facturaEncontrada = true;
                    break;
                }
            }
            
            if (!facturaEncontrada) {
                JOptionPane.showMessageDialog(this, 
                    "No se encontró la factura con el número: " + numeroFactura, 
                    "Factura no encontrada", 
                    JOptionPane.INFORMATION_MESSAGE);
                
            }
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, 
                "Error al leer el archivo de facturas: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void cargarDatosEnCampos(String[] datos) {
        try {
        
            NumeroFactura.setText(datos[0]);
            Fecha.setText(datos[1]);
            Nombre.setText(datos[2]);
            Apellido.setText(datos[3]);
            TipoDocumento1.setSelectedItem(datos[4]);
            NumeroId.setText(datos[5]);
            NumPropiedad.setText(datos[6]);
            ValorAdmon.setText(datos[7]);
            
            // Configurar cuentas vencidas
            CtasVencidas.setSelectedItem(datos[8]);
            Nacionalidad.setText(datos[9]); // Valor ctas vencidas
            
            // Configurar multas
            Multas.setSelectedItem(datos[10]);
            Nacionalidad2.setText(datos[11]); // Valor multas
            
            // Configurar descuentos
            Descuentos.setSelectedItem(datos[12]);
            Nacionalidad1.setText(datos[13]); // Valor descuentos
            
            // Total
            Total.setText(datos[14]);
            
        } catch (ArrayIndexOutOfBoundsException e) {
            JOptionPane.showMessageDialog(this, 
                "Error en el formato de los datos de la factura", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_BuscarActionPerformed

    private void CtasVencidasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CtasVencidasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CtasVencidasActionPerformed

    private void NacionalidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NacionalidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NacionalidadActionPerformed

    private void NumPropiedadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumPropiedadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumPropiedadActionPerformed

    private void ValorAdmonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ValorAdmonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ValorAdmonActionPerformed

    private void TotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TotalActionPerformed

    private void NumeroFacturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumeroFacturaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumeroFacturaActionPerformed

    private void FechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FechaActionPerformed

    private void TipoDocumento1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoDocumento1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TipoDocumento1ActionPerformed

    private void DescuentosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DescuentosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DescuentosActionPerformed

    private void Nacionalidad1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Nacionalidad1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Nacionalidad1ActionPerformed

    private void MultasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MultasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MultasActionPerformed

    private void Nacionalidad2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Nacionalidad2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Nacionalidad2ActionPerformed

    private void GenerarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GenerarActionPerformed
        FacturaPDF pdfGenerator = new FacturaPDF();
        pdfGenerator.generateInvoice(
        Nombre.getText(), 
        Apellido.getText(), 
        NumeroId.getText(), 
        NumPropiedad.getText(),
        ValorAdmon.getText(),
        Total.getText(),
        Fecha.getText(),
        NumeroFactura.getText()
    );
    }//GEN-LAST:event_GenerarActionPerformed

    private void NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreActionPerformed

    private void ApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ApellidoActionPerformed

    private void Cancelar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Cancelar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Cancelar1ActionPerformed
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Apellido;
    private javax.swing.JButton Buscar;
    private javax.swing.JButton Cancelar1;
    private javax.swing.JComboBox<String> CtasVencidas;
    private javax.swing.JComboBox<String> Descuentos;
    private javax.swing.JTextField Fecha;
    private javax.swing.JButton Generar;
    private javax.swing.JComboBox<String> Multas;
    private javax.swing.JTextField Nacionalidad;
    private javax.swing.JTextField Nacionalidad1;
    private javax.swing.JTextField Nacionalidad2;
    private javax.swing.JTextField Nombre;
    private javax.swing.JTextField NumPropiedad;
    private javax.swing.JTextField NumeroFactura;
    private javax.swing.JTextField NumeroId;
    private javax.swing.JButton Salir1;
    private javax.swing.JComboBox<String> TipoDocumento1;
    private javax.swing.JLabel Titulo;
    private javax.swing.JTextField Total;
    private javax.swing.JTextField ValorAdmon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
