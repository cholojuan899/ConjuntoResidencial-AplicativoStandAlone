package com.mycompany.Windows;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class EditarAreaComun extends javax.swing.JFrame {

    public EditarAreaComun() {
    initComponents();  // Inicializa los componentes de la ventana
    setLocationRelativeTo(null);
    pack();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        Titulo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Guardar = new javax.swing.JButton();
        Buscar = new javax.swing.JButton();
        Salir = new javax.swing.JButton();
        Capacidad = new javax.swing.JTextField();
        NombreAreaComun = new javax.swing.JTextField();
        PeriodicidadMantenimiento = new javax.swing.JTextField();
        ConstoMantenimiento = new javax.swing.JTextField();
        DiasServicio = new javax.swing.JTextField();
        HoraApertura = new javax.swing.JTextField();
        HoraCierre = new javax.swing.JTextField();
        Cancelar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(900, 600));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(92, 123, 105));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator1.setToolTipText("");
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 880, 10));

        Titulo.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Titulo.setForeground(new java.awt.Color(200, 215, 189));
        Titulo.setText("Editar Área Común");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/LETRAS.png"))); // NOI18N
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 490, -1, 50));

        Guardar.setBackground(new java.awt.Color(159, 191, 166));
        Guardar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Guardar.setForeground(new java.awt.Color(0, 0, 0));
        Guardar.setText("Guardar");
        Guardar.setToolTipText("");
        Guardar.setBorderPainted(false);
        Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarActionPerformed(evt);
            }
        });
        jPanel1.add(Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 520, -1, -1));

        Buscar.setBackground(new java.awt.Color(165, 159, 191));
        Buscar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Buscar.setForeground(new java.awt.Color(0, 0, 0));
        Buscar.setText("Buscar");
        Buscar.setToolTipText("");
        Buscar.setBorderPainted(false);
        Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarActionPerformed(evt);
            }
        });
        jPanel1.add(Buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 70, -1, -1));

        Salir.setBackground(new java.awt.Color(159, 191, 166));
        Salir.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Salir.setForeground(new java.awt.Color(0, 0, 0));
        Salir.setText("Atrás");
        Salir.setToolTipText("");
        Salir.setBorderPainted(false);
        Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirActionPerformed(evt);
            }
        });
        jPanel1.add(Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 10, -1, -1));

        Capacidad.setBackground(new java.awt.Color(255, 255, 255));
        Capacidad.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Capacidad.setForeground(new java.awt.Color(153, 153, 153));
        Capacidad.setText("Capacidad");
        Capacidad.setToolTipText("");
        Capacidad.setBorder(null);
        Capacidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CapacidadActionPerformed(evt);
            }
        });
        jPanel1.add(Capacidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 160, 280, 30));

        NombreAreaComun.setBackground(new java.awt.Color(255, 255, 255));
        NombreAreaComun.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NombreAreaComun.setForeground(new java.awt.Color(153, 153, 153));
        NombreAreaComun.setText("Nombre del Área Común");
        NombreAreaComun.setBorder(null);
        NombreAreaComun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreAreaComunActionPerformed(evt);
            }
        });
        jPanel1.add(NombreAreaComun, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 580, 30));

        PeriodicidadMantenimiento.setBackground(new java.awt.Color(255, 255, 255));
        PeriodicidadMantenimiento.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        PeriodicidadMantenimiento.setForeground(new java.awt.Color(153, 153, 153));
        PeriodicidadMantenimiento.setText("Peridicidad de Mantenimiento");
        PeriodicidadMantenimiento.setBorder(null);
        PeriodicidadMantenimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PeriodicidadMantenimientoActionPerformed(evt);
            }
        });
        jPanel1.add(PeriodicidadMantenimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 430, 30));

        ConstoMantenimiento.setBackground(new java.awt.Color(255, 255, 255));
        ConstoMantenimiento.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        ConstoMantenimiento.setForeground(new java.awt.Color(153, 153, 153));
        ConstoMantenimiento.setText("Costo Mantenimiento (c/u)");
        ConstoMantenimiento.setBorder(null);
        ConstoMantenimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConstoMantenimientoActionPerformed(evt);
            }
        });
        jPanel1.add(ConstoMantenimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 210, 430, 30));

        DiasServicio.setBackground(new java.awt.Color(255, 255, 255));
        DiasServicio.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        DiasServicio.setForeground(new java.awt.Color(153, 153, 153));
        DiasServicio.setText("Cantidad de Dias de Servicio");
        DiasServicio.setBorder(null);
        DiasServicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DiasServicioActionPerformed(evt);
            }
        });
        jPanel1.add(DiasServicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 430, 30));

        HoraApertura.setBackground(new java.awt.Color(255, 255, 255));
        HoraApertura.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        HoraApertura.setForeground(new java.awt.Color(153, 153, 153));
        HoraApertura.setText("Hora de Apertura");
        HoraApertura.setToolTipText("");
        HoraApertura.setBorder(null);
        HoraApertura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HoraAperturaActionPerformed(evt);
            }
        });
        jPanel1.add(HoraApertura, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 280, 30));

        HoraCierre.setBackground(new java.awt.Color(255, 255, 255));
        HoraCierre.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        HoraCierre.setForeground(new java.awt.Color(153, 153, 153));
        HoraCierre.setText("Hora de Cierre");
        HoraCierre.setToolTipText("");
        HoraCierre.setBorder(null);
        HoraCierre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HoraCierreActionPerformed(evt);
            }
        });
        jPanel1.add(HoraCierre, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 160, 280, 30));

        Cancelar.setBackground(new java.awt.Color(159, 191, 166));
        Cancelar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Cancelar.setForeground(new java.awt.Color(0, 0, 0));
        Cancelar.setText("Cancelar");
        Cancelar.setToolTipText("");
        Cancelar.setBorderPainted(false);
        Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarActionPerformed(evt);
            }
        });
        jPanel1.add(Cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 520, -1, -1));

        jLabel1.setBackground(new java.awt.Color(204, 255, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/HOJA.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 900, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CapacidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CapacidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CapacidadActionPerformed

    private void SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirActionPerformed
        MenuAreasComunes mAreasComunes = new MenuAreasComunes();
        mAreasComunes.setVisible(true);
        mAreasComunes.setLocationRelativeTo(null);
        pack();
        dispose();
    }//GEN-LAST:event_SalirActionPerformed

    private void BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarActionPerformed
            String nombreArea = NombreAreaComun.getText().trim(); // Obtener el nombre del área común a buscar

    // Ruta del archivo CSV en la carpeta data
    String filePath = "data/AreasComunes.csv";
    boolean encontrado = false; 

    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
        String linea;
        br.readLine(); // Leer la cabecera y descartarla

        while ((linea = br.readLine()) != null) {
            String[] datos = linea.split(","); // Separar los datos por comas

            // Verificar si el nombre del área común coincide
            if (datos[0].equalsIgnoreCase(nombreArea)) {
                // Llenar los JTextFields con los datos encontrados
                NombreAreaComun.setText(datos[0]);
                ConstoMantenimiento.setText(datos[1]);
                HoraApertura.setText(datos[2]);
                HoraCierre.setText(datos[3]);
                PeriodicidadMantenimiento.setText(datos[4]);
                DiasServicio.setText(datos[5]);
                Capacidad.setText(datos[6]); 
                encontrado = true;
                break; // Salir del bucle si se encontró el área
            }
        }

        if (!encontrado) {
            javax.swing.JOptionPane.showMessageDialog(this, "Área común no encontrada.");
        }

    } catch (IOException e) {
        e.printStackTrace();
        javax.swing.JOptionPane.showMessageDialog(this, "Error al buscar los datos.");
    }
    }//GEN-LAST:event_BuscarActionPerformed

    private void GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarActionPerformed
        String capacidad = Capacidad.getText();
        String diasServicio = DiasServicio.getText();
        String nombreAreaComun = NombreAreaComun.getText();
        String costoMantenimiento = ConstoMantenimiento.getText();
        String horaApertura = HoraApertura.getText();
        String horaCierre = HoraCierre.getText();
        String periodicidadMantenimiento = PeriodicidadMantenimiento.getText();
        
        // Ruta del archivo CSV en la carpeta data
        String filePath = "data/AreasComunes.csv";

        try (FileWriter writer = new FileWriter(filePath, false)) { // 'false' para sobrescribir el archivo
        // Escribir el encabezado
        writer.write("NombreAreaComun,CostoMantenimiento,HoraApertura,HoraCierre,PeriodicidadMantenimiento,diasServicio,Capacidad\n");

        // Escribir los datos
        writer.write(nombreAreaComun + "," + costoMantenimiento + "," + horaApertura + "," + horaCierre + "," + periodicidadMantenimiento + "," + diasServicio + "," + capacidad  + "\n");

        // Mensaje de éxito
        javax.swing.JOptionPane.showMessageDialog(this, "Datos guardados correctamente.");

        } catch (IOException e) {
        e.printStackTrace();
        javax.swing.JOptionPane.showMessageDialog(this, "Error al guardar los datos.");
        }
    }//GEN-LAST:event_GuardarActionPerformed

    private void NombreAreaComunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreAreaComunActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreAreaComunActionPerformed

    private void PeriodicidadMantenimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PeriodicidadMantenimientoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PeriodicidadMantenimientoActionPerformed

    private void ConstoMantenimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConstoMantenimientoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ConstoMantenimientoActionPerformed

    private void DiasServicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DiasServicioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DiasServicioActionPerformed

    private void HoraAperturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HoraAperturaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_HoraAperturaActionPerformed

    private void HoraCierreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HoraCierreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_HoraCierreActionPerformed

    private void CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarActionPerformed
        String capacidad = Capacidad.getText();
        String diasServicio = DiasServicio.getText();
        String nombreAreaComun = NombreAreaComun.getText();
        String costoMantenimiento = ConstoMantenimiento.getText();
        String horaApertura = HoraApertura.getText();
        String horaCierre = HoraCierre.getText();
        String periodicidadMantenimiento = PeriodicidadMantenimiento.getText();
        
        // Ruta del archivo CSV en la carpeta data
        String filePath = "data/AreasComunes.csv";

        try (FileWriter writer = new FileWriter(filePath, false)) { // 'false' para sobrescribir el archivo
        // Escribir el encabezado
        writer.write("NombreAreaComun,CostoMantenimiento,HoraApertura,HoraCierre,PeriodicidadMantenimiento,diasServicio,Capacidad\n");

        // Escribir los datos
        writer.write(nombreAreaComun + "," + costoMantenimiento + "," + horaApertura + "," + horaCierre + "," + periodicidadMantenimiento + "," + diasServicio + "," + capacidad  + "\n");

        // Mensaje de éxito
        javax.swing.JOptionPane.showMessageDialog(this, "Datos guardados correctamente.");

        } catch (IOException e) {
        e.printStackTrace();
        javax.swing.JOptionPane.showMessageDialog(this, "Error al guardar los datos.");
        }
    }//GEN-LAST:event_CancelarActionPerformed
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Buscar;
    private javax.swing.JButton Cancelar;
    private javax.swing.JTextField Capacidad;
    private javax.swing.JTextField ConstoMantenimiento;
    private javax.swing.JTextField DiasServicio;
    private javax.swing.JButton Guardar;
    private javax.swing.JTextField HoraApertura;
    private javax.swing.JTextField HoraCierre;
    private javax.swing.JTextField NombreAreaComun;
    private javax.swing.JTextField PeriodicidadMantenimiento;
    private javax.swing.JButton Salir;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
