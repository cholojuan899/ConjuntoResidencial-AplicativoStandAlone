package com.mycompany.Windows;

import com.mycompany.Windows.MenuTipoUsuario;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;

public class Login extends javax.swing.JFrame {

    public Login() {
        initComponents();
    setLocationRelativeTo(null);
    }
        

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        ImagenTitle = new javax.swing.JLabel();
        FondoInf = new javax.swing.JPanel();
        CampoUsuario = new javax.swing.JTextField();
        Contraseña = new javax.swing.JLabel();
        Usuario = new javax.swing.JLabel();
        Logo = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jPasswordField1 = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Fondo.setBackground(new java.awt.Color(255, 255, 255));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ImagenTitle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/LoginTitle.jpeg"))); // NOI18N
        ImagenTitle.setText("jLabel1");
        Fondo.add(ImagenTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 440));

        FondoInf.setBackground(new java.awt.Color(0, 51, 16));
        FondoInf.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        CampoUsuario.setBackground(new java.awt.Color(217, 217, 217));
        CampoUsuario.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        CampoUsuario.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        CampoUsuario.setBorder(null);
        CampoUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CampoUsuarioActionPerformed(evt);
            }
        });
        FondoInf.add(CampoUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 50, 240, 33));

        Contraseña.setBackground(new java.awt.Color(255, 255, 255));
        Contraseña.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Contraseña.setForeground(new java.awt.Color(255, 255, 255));
        Contraseña.setText("Contraseña");
        FondoInf.add(Contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(308, 21, -1, -1));

        Usuario.setBackground(new java.awt.Color(255, 255, 255));
        Usuario.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Usuario.setForeground(new java.awt.Color(255, 255, 255));
        Usuario.setText("Usuario");
        FondoInf.add(Usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 21, -1, -1));

        Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Santa Monica Campestre (128 x 128 px)(3).png"))); // NOI18N
        FondoInf.add(Logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(712, 0, 182, 154));

        jButton1.setBackground(new java.awt.Color(204, 204, 204));
        jButton1.setFont(new java.awt.Font("Montserrat", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 0));
        jButton1.setText("Crear Usuario");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        FondoInf.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 117, -1, -1));

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("¿No tiene Usuario Registrado?");
        FondoInf.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 95, -1, -1));

        jButton2.setBackground(new java.awt.Color(204, 204, 204));
        jButton2.setFont(new java.awt.Font("Montserrat", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 0, 0));
        jButton2.setText("Entrar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        FondoInf.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 50, -1, -1));

        jPasswordField1.setBackground(new java.awt.Color(255, 255, 255));
        jPasswordField1.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        jPasswordField1.setForeground(new java.awt.Color(0, 0, 0));
        jPasswordField1.setBorder(null);
        jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField1ActionPerformed(evt);
            }
        });
        FondoInf.add(jPasswordField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 50, 200, 30));

        Fondo.add(FondoInf, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 450, -1, 150));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CampoUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CampoUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CampoUsuarioActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String userId = CampoUsuario.getText(); // Obtener el número de identificación del campo de texto
    String password = new String(jPasswordField1.getPassword()); // Obtener la contraseña
    String filePath1 = System.getProperty("user.dir") + "data/empleados.csv"; // Ruta del primer archivo CSV
    String filePath2 = System.getProperty("user.dir") + "data/propietarios.csv"; // Ruta del segundo archivo CSV

    // Intentar autenticar en los dos archivos
    if (authenticateInFile(filePath1, userId, password) || authenticateInFile(filePath2, userId, password)) {
        JOptionPane.showMessageDialog(this, "Autenticación exitosa.");
        // Aquí puedes agregar la lógica para redirigir al usuario a la siguiente ventana
    } else {
        JOptionPane.showMessageDialog(this, "Número de identificación o contraseña incorrectos.");
    }
}

// Método para autenticar en un archivo CSV
private boolean authenticateInFile(String filePath, String userId, String password) {
    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
        String line;
        while ((line = br.readLine()) != null) {
            String[] data = line.split(",");
            // Suponiendo que el CSV tiene el formato: id,password
            if (data.length >= 2 && data[0].equals(userId) && data[1].equals(password)) {
                return true; // Usuario autenticado
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al leer el archivo " + filePath);
    }
    return false; // No autenticado en este archivo
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jPasswordField1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        MenuTipoUsuario menuTipoUsuario = new MenuTipoUsuario();
        menuTipoUsuario.setVisible(true);
        dispose();
    
    }//GEN-LAST:event_jButton1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField CampoUsuario;
    private javax.swing.JLabel Contraseña;
    private javax.swing.JPanel Fondo;
    private javax.swing.JPanel FondoInf;
    private javax.swing.JLabel ImagenTitle;
    private javax.swing.JLabel Logo;
    private javax.swing.JLabel Usuario;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPasswordField jPasswordField1;
    // End of variables declaration//GEN-END:variables

}