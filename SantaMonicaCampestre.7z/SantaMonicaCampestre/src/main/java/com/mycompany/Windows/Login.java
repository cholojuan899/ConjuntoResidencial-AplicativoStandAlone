package com.mycompany.Windows;

import com.mycompany.Windows.MenuTipoUsuario;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;

public class Login extends javax.swing.JFrame {

    public Login() {
    initComponents();
    setLocationRelativeTo(null);
    setSize(900, 600);
    }
        

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        ImagenTitle = new javax.swing.JLabel();
        FondoInf = new javax.swing.JPanel();
        CampoUsuario = new javax.swing.JTextField();
        Contraseña = new javax.swing.JLabel();
        Usuario = new javax.swing.JLabel();
        Logo = new javax.swing.JLabel();
        CrearUsuario = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        Entrar = new javax.swing.JButton();
        CampoContraseña = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Fondo.setBackground(new java.awt.Color(255, 255, 255));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ImagenTitle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/LoginTitle.jpeg"))); // NOI18N
        ImagenTitle.setText("jLabel1");
        Fondo.add(ImagenTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 450));

        FondoInf.setBackground(new java.awt.Color(0, 51, 16));
        FondoInf.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        CampoUsuario.setBackground(new java.awt.Color(217, 217, 217));
        CampoUsuario.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        CampoUsuario.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        CampoUsuario.setBorder(null);
        CampoUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CampoUsuarioActionPerformed(evt);
            }
        });
        FondoInf.add(CampoUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 240, 33));

        Contraseña.setBackground(new java.awt.Color(255, 255, 255));
        Contraseña.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Contraseña.setForeground(new java.awt.Color(255, 255, 255));
        Contraseña.setText("Contraseña");
        FondoInf.add(Contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, -1, -1));

        Usuario.setBackground(new java.awt.Color(255, 255, 255));
        Usuario.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Usuario.setForeground(new java.awt.Color(255, 255, 255));
        Usuario.setText("Usuario");
        FondoInf.add(Usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, -1, -1));

        Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Santa Monica Campestre (128 x 128 px)(3).png"))); // NOI18N
        FondoInf.add(Logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 0, 182, 150));

        CrearUsuario.setBackground(new java.awt.Color(204, 204, 204));
        CrearUsuario.setFont(new java.awt.Font("Montserrat", 1, 12)); // NOI18N
        CrearUsuario.setForeground(new java.awt.Color(0, 0, 0));
        CrearUsuario.setText("Crear Usuario");
        CrearUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CrearUsuarioActionPerformed(evt);
            }
        });
        FondoInf.add(CrearUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("¿No tiene Usuario Registrado?");
        FondoInf.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, -1, -1));

        Entrar.setBackground(new java.awt.Color(204, 204, 204));
        Entrar.setFont(new java.awt.Font("Montserrat", 1, 12)); // NOI18N
        Entrar.setForeground(new java.awt.Color(0, 0, 0));
        Entrar.setText("Entrar");
        Entrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EntrarActionPerformed(evt);
            }
        });
        FondoInf.add(Entrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 40, -1, -1));

        CampoContraseña.setBackground(new java.awt.Color(255, 255, 255));
        CampoContraseña.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        CampoContraseña.setForeground(new java.awt.Color(0, 0, 0));
        CampoContraseña.setBorder(null);
        CampoContraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CampoContraseñaActionPerformed(evt);
            }
        });
        FondoInf.add(CampoContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 40, 200, 30));

        Fondo.add(FondoInf, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 450, 900, 150));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CampoUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CampoUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CampoUsuarioActionPerformed

    private void EntrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EntrarActionPerformed
    String usuario = CampoUsuario.getText(); // Obtener el número de identificación del campo de texto
    String contraseña = new String(CampoContraseña.getPassword()); // Obtener la contraseña
    String ruta = "data/usuarios.csv"; // Ruta del primer archivo CSV
    
    // Intentar autenticar en los dos archivos
    if (autenticarCsv(ruta, usuario, contraseña)) {
        JOptionPane.showMessageDialog(this, "Autenticación exitosa.");
        MenuPrincipal menuPr = new MenuPrincipal();
        menuPr.setVisible(true);
        menuPr.setLocationRelativeTo(null);
        dispose();
    } else {
        JOptionPane.showMessageDialog(this, "Número de identificación o contraseña incorrectos.");
    }
}

private boolean autenticarCsv(String ruta, String usuario, String contraseña) {
    try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
        String line;
        while ((line = br.readLine()) != null) {
            String[] data = line.split(",");
            if (data.length >= 4 && data[2].equals(usuario) && data[3].equals(contraseña)) {
                return true; // Usuario autenticado
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al leer el archivo " + ruta);
    }
    return false; // No autenticado 
    }//GEN-LAST:event_EntrarActionPerformed

    private void CampoContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CampoContraseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CampoContraseñaActionPerformed

    private void CrearUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CrearUsuarioActionPerformed
        MenuTipoUsuario menuTipoUsuario = new MenuTipoUsuario();
        menuTipoUsuario.setVisible(true);
        menuTipoUsuario.setLocationRelativeTo(null);
        pack();
        dispose();
    
    }//GEN-LAST:event_CrearUsuarioActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField CampoContraseña;
    private javax.swing.JTextField CampoUsuario;
    private javax.swing.JLabel Contraseña;
    private javax.swing.JButton CrearUsuario;
    private javax.swing.JButton Entrar;
    private javax.swing.JPanel Fondo;
    private javax.swing.JPanel FondoInf;
    private javax.swing.JLabel ImagenTitle;
    private javax.swing.JLabel Logo;
    private javax.swing.JLabel Usuario;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables

}