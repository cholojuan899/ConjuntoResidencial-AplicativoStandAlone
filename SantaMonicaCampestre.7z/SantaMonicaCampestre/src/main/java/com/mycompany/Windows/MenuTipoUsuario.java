package com.mycompany.Windows;


public class MenuTipoUsuario extends javax.swing.JFrame {

    public MenuTipoUsuario() {
    initComponents();  // Inicializa los componentes de la ventana
    setLocationRelativeTo(null);
    setSize(900, 600);
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Bienvenido = new javax.swing.JLabel();
        MenuPricipal = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        Titulo = new javax.swing.JLabel();
        Salir = new javax.swing.JButton();
        Empleados = new javax.swing.JButton();
        Propietarios = new javax.swing.JButton();
        Logo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(200, 215, 189));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Bienvenido.setFont(new java.awt.Font("Amaranth", 1, 56)); // NOI18N
        Bienvenido.setForeground(new java.awt.Color(0, 0, 0));
        Bienvenido.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Bienvenido.setText("Bienvenido");
        Bienvenido.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel1.add(Bienvenido, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 103, 900, -1));

        MenuPricipal.setFont(new java.awt.Font("Amaranth", 0, 18)); // NOI18N
        MenuPricipal.setForeground(new java.awt.Color(0, 51, 16));
        MenuPricipal.setText("Elija su tipo de Usuario");
        jPanel1.add(MenuPricipal, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 180, -1, -1));

        jSeparator1.setToolTipText("");
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 880, 10));

        Titulo.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Titulo.setForeground(new java.awt.Color(0, 51, 16));
        Titulo.setText("Santa Mónica Campestre");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        Salir.setBackground(new java.awt.Color(159, 191, 166));
        Salir.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Salir.setForeground(new java.awt.Color(0, 0, 0));
        Salir.setText("Salir");
        Salir.setToolTipText("");
        Salir.setBorderPainted(false);
        Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirActionPerformed(evt);
            }
        });
        jPanel1.add(Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 10, -1, -1));

        Empleados.setBackground(new java.awt.Color(200, 215, 189));
        Empleados.setFont(new java.awt.Font("Montserrat", 1, 22)); // NOI18N
        Empleados.setForeground(new java.awt.Color(0, 0, 0));
        Empleados.setText("EMPLEADOS");
        Empleados.setBorderPainted(false);
        Empleados.setContentAreaFilled(false);
        Empleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmpleadosActionPerformed(evt);
            }
        });
        jPanel1.add(Empleados, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 257, -1, -1));

        Propietarios.setBackground(new java.awt.Color(200, 215, 189));
        Propietarios.setFont(new java.awt.Font("Montserrat", 1, 22)); // NOI18N
        Propietarios.setForeground(new java.awt.Color(0, 0, 0));
        Propietarios.setText("PROPIETARIOS");
        Propietarios.setBorderPainted(false);
        Propietarios.setContentAreaFilled(false);
        Propietarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PropietariosActionPerformed(evt);
            }
        });
        jPanel1.add(Propietarios, new org.netbeans.lib.awtextra.AbsoluteConstraints(568, 257, -1, -1));

        Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Santa Monica Campestre (128 x 128 px)(3).png"))); // NOI18N
        jPanel1.add(Logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 450, -1, 140));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/HOJA.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 200, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirActionPerformed
  
        Login login = new Login();
        login.setVisible(true);
        login.setLocationRelativeTo(null);
        setSize(900, 600);
        dispose();
    }//GEN-LAST:event_SalirActionPerformed

    private void EmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmpleadosActionPerformed
        RegitrarUsuarioEmpleado rEmpleados = new RegitrarUsuarioEmpleado();
        rEmpleados.setVisible(true);
        rEmpleados.setLocationRelativeTo(null);
        setSize(900, 600);
        dispose();
    }//GEN-LAST:event_EmpleadosActionPerformed

    private void PropietariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PropietariosActionPerformed
        RegistrarUsuariosPropietarios rPropietarios = new RegistrarUsuariosPropietarios();
        rPropietarios.setVisible(true);
        rPropietarios.setLocationRelativeTo(null);
        setSize(900, 600);
        dispose();
    }//GEN-LAST:event_PropietariosActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Bienvenido;
    private javax.swing.JButton Empleados;
    private javax.swing.JLabel Logo;
    private javax.swing.JLabel MenuPricipal;
    private javax.swing.JButton Propietarios;
    private javax.swing.JButton Salir;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
