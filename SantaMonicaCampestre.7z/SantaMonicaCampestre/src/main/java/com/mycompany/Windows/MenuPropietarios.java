package com.mycompany.Windows;


public class MenuPropietarios extends javax.swing.JFrame {

    public MenuPropietarios() {
    initComponents();  // Inicializa los componentes de la ventana
    setLocationRelativeTo(null);
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Bienvenido = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        Titulo = new javax.swing.JLabel();
        Salir = new javax.swing.JButton();
        Registrar = new javax.swing.JButton();
        GenerarCsv = new javax.swing.JButton();
        Editar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(92, 123, 105));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Bienvenido.setFont(new java.awt.Font("Amaranth", 1, 56)); // NOI18N
        Bienvenido.setForeground(new java.awt.Color(0, 0, 0));
        Bienvenido.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Bienvenido.setText("Propietarios");
        Bienvenido.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel1.add(Bienvenido, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 900, -1));

        jSeparator1.setToolTipText("");
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 880, 10));

        Titulo.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Titulo.setForeground(new java.awt.Color(200, 215, 189));
        Titulo.setText("Santa Mónica Campestre");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        Salir.setBackground(new java.awt.Color(159, 191, 166));
        Salir.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Salir.setForeground(new java.awt.Color(0, 0, 0));
        Salir.setText("Atrás");
        Salir.setToolTipText("");
        Salir.setBorderPainted(false);
        Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirActionPerformed(evt);
            }
        });
        jPanel1.add(Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 10, -1, -1));

        Registrar.setBackground(new java.awt.Color(200, 215, 189));
        Registrar.setFont(new java.awt.Font("Montserrat", 1, 22)); // NOI18N
        Registrar.setForeground(new java.awt.Color(0, 0, 0));
        Registrar.setBorderPainted(false);
        Registrar.setContentAreaFilled(false);
        Registrar.setLabel("REGISTRAR ");
        Registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegistrarActionPerformed(evt);
            }
        });
        jPanel1.add(Registrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 290, 170, -1));

        GenerarCsv.setBackground(new java.awt.Color(200, 215, 189));
        GenerarCsv.setFont(new java.awt.Font("Montserrat", 1, 22)); // NOI18N
        GenerarCsv.setForeground(new java.awt.Color(0, 0, 0));
        GenerarCsv.setText("GENERAR CSV");
        GenerarCsv.setBorderPainted(false);
        GenerarCsv.setContentAreaFilled(false);
        GenerarCsv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GenerarCsvActionPerformed(evt);
            }
        });
        jPanel1.add(GenerarCsv, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 290, -1, -1));

        Editar.setBackground(new java.awt.Color(99, 0, 142));
        Editar.setFont(new java.awt.Font("Montserrat", 1, 22)); // NOI18N
        Editar.setForeground(new java.awt.Color(0, 0, 0));
        Editar.setBorderPainted(false);
        Editar.setContentAreaFilled(false);
        Editar.setLabel("EDITAR");
        Editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditarActionPerformed(evt);
            }
        });
        jPanel1.add(Editar, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 290, -1, -1));

        jLabel1.setBackground(new java.awt.Color(204, 255, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/HOJA.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 900, -1));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/LETRAS.png"))); // NOI18N
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 530, -1, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirActionPerformed
        MenuPrincipal mPrincipal = new MenuPrincipal();
        mPrincipal .setVisible(true);
        mPrincipal .setLocationRelativeTo(null);
        dispose();
    }//GEN-LAST:event_SalirActionPerformed

    private void RegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegistrarActionPerformed
        RegistrarPropietarios rPropietarios = new RegistrarPropietarios();
        rPropietarios.setVisible(true);
        rPropietarios.setLocationRelativeTo(null);
        dispose();
    }//GEN-LAST:event_RegistrarActionPerformed

    private void GenerarCsvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GenerarCsvActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_GenerarCsvActionPerformed

    private void EditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditarActionPerformed
        EditarPropietarios ePropietarios = new EditarPropietarios();
        ePropietarios.setVisible(true);
        ePropietarios.setLocationRelativeTo(null);
        dispose();
    }//GEN-LAST:event_EditarActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Bienvenido;
    private javax.swing.JButton Editar;
    private javax.swing.JButton GenerarCsv;
    private javax.swing.JButton Registrar;
    private javax.swing.JButton Salir;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
