package com.mycompany.Utilidades;

import com.mycompany.Windows.Login;
import javax.swing.JFrame;

public class SantaMonicaCampestre {

    public static void main(String[] args) {      
        Login principal = new Login();
        principal.setVisible(true);
        principal.pack();
        principal.setLocationRelativeTo(null);
    }
}
 