package com.mycompany.Utilidades;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.io.IOException;

public class FacturaPDF {

    public void generateInvoice(String nombre, String apellido, String numeroId, String numPropiedad, String valorAdmon, String total, String fecha, String numeroFactura) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream("Factura.pdf"));
            document.open();
            document.add(new Paragraph("Factura"));
            document.add(new Paragraph("Nombre: " + nombre));
            document.add(new Paragraph("Apellido: " + apellido));
            document.add(new Paragraph("Numero de Documento: " + numeroId));
            document.add(new Paragraph("Numero de Propiedad: " + numPropiedad));
            document.add(new Paragraph("Valor Administración: " + valorAdmon));
            document.add(new Paragraph("Total: " + total));
            document.add(new Paragraph("Fecha: " + fecha));
            document.add(new Paragraph("Numero de Factura: " + numeroFactura));
            // Add ComboBox values to the PDF
        } catch (DocumentException | IOException e) {
            e.printStackTrace();
        } finally {
            document.close();
        }
    }
}