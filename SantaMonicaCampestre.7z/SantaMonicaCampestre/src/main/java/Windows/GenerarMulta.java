package Windows;


public class GenerarMulta extends javax.swing.JFrame {

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        Titulo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Guardar = new javax.swing.JButton();
        Cancelar = new javax.swing.JButton();
        Salir1 = new javax.swing.JButton();
        Apellido = new javax.swing.JTextField();
        NumeroId = new javax.swing.JTextField();
        Nacionalidad = new javax.swing.JTextField();
        Nombre = new javax.swing.JTextField();
        TelFijo = new javax.swing.JTextField();
        Celular = new javax.swing.JTextField();
        Contraseña = new javax.swing.JTextField();
        Salario = new javax.swing.JTextField();
        TipoDocumento1 = new javax.swing.JComboBox<>();
        Nacionalidad2 = new javax.swing.JTextField();
        Nacionalidad3 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(159, 191, 166));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator1.setToolTipText("");
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 880, 10));

        Titulo.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Titulo.setForeground(new java.awt.Color(0, 51, 16));
        Titulo.setText("Generar Multa");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/LETRAS.png"))); // NOI18N
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 540, -1, 50));

        Guardar.setBackground(new java.awt.Color(165, 159, 191));
        Guardar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Guardar.setForeground(new java.awt.Color(0, 0, 0));
        Guardar.setText(" Generar JSON");
        Guardar.setToolTipText("");
        Guardar.setBorderPainted(false);
        Guardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarActionPerformed(evt);
            }
        });
        jPanel1.add(Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 550, -1, -1));

        Cancelar.setBackground(new java.awt.Color(92, 123, 105));
        Cancelar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Cancelar.setForeground(new java.awt.Color(0, 0, 0));
        Cancelar.setText("Cancelar");
        Cancelar.setToolTipText("");
        Cancelar.setBorderPainted(false);
        Cancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarActionPerformed(evt);
            }
        });
        jPanel1.add(Cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 550, -1, -1));

        Salir1.setBackground(new java.awt.Color(92, 123, 105));
        Salir1.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Salir1.setForeground(new java.awt.Color(0, 0, 0));
        Salir1.setToolTipText("");
        Salir1.setBorderPainted(false);
        Salir1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Salir1.setHideActionText(true);
        Salir1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Salir1.setLabel("");
        Salir1.setName("Observaciones"); // NOI18N
        Salir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Salir1ActionPerformed(evt);
            }
        });
        jPanel1.add(Salir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 10, -1, -1));

        Apellido.setBackground(new java.awt.Color(255, 255, 255));
        Apellido.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Apellido.setForeground(new java.awt.Color(153, 153, 153));
        Apellido.setText("Apellido");
        Apellido.setBorder(null);
        Apellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ApellidoActionPerformed(evt);
            }
        });
        jPanel1.add(Apellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 70, 430, 30));

        NumeroId.setBackground(new java.awt.Color(255, 255, 255));
        NumeroId.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NumeroId.setForeground(new java.awt.Color(153, 153, 153));
        NumeroId.setText("Numero de Documento");
        NumeroId.setToolTipText("");
        NumeroId.setBorder(null);
        NumeroId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumeroIdActionPerformed(evt);
            }
        });
        jPanel1.add(NumeroId, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 120, 650, 30));

        Nacionalidad.setBackground(new java.awt.Color(255, 255, 255));
        Nacionalidad.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Nacionalidad.setForeground(new java.awt.Color(153, 153, 153));
        Nacionalidad.setText("Valor de la Multa");
        Nacionalidad.setBorder(null);
        Nacionalidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NacionalidadActionPerformed(evt);
            }
        });
        jPanel1.add(Nacionalidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 220, 280, 30));

        Nombre.setBackground(new java.awt.Color(255, 255, 255));
        Nombre.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Nombre.setForeground(new java.awt.Color(153, 153, 153));
        Nombre.setText("Nombre");
        Nombre.setBorder(null);
        Nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreActionPerformed(evt);
            }
        });
        jPanel1.add(Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 430, 30));

        TelFijo.setBackground(new java.awt.Color(255, 255, 255));
        TelFijo.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        TelFijo.setForeground(new java.awt.Color(153, 153, 153));
        TelFijo.setText("Numero de Propiedad");
        TelFijo.setBorder(null);
        TelFijo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TelFijoActionPerformed(evt);
            }
        });
        jPanel1.add(TelFijo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 430, 30));

        Celular.setBackground(new java.awt.Color(255, 255, 255));
        Celular.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Celular.setForeground(new java.awt.Color(153, 153, 153));
        Celular.setText("Lugar de Ocurrencia");
        Celular.setBorder(null);
        Celular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CelularActionPerformed(evt);
            }
        });
        jPanel1.add(Celular, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 170, 430, 30));

        Contraseña.setBackground(new java.awt.Color(255, 255, 255));
        Contraseña.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Contraseña.setForeground(new java.awt.Color(153, 153, 153));
        Contraseña.setText("Fecha del Evento");
        Contraseña.setToolTipText("");
        Contraseña.setBorder(null);
        Contraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContraseñaActionPerformed(evt);
            }
        });
        jPanel1.add(Contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 450, 430, 30));

        Salario.setBackground(new java.awt.Color(255, 255, 255));
        Salario.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Salario.setForeground(new java.awt.Color(153, 153, 153));
        Salario.setText("Fecha del Reporte");
        Salario.setBorder(null);
        Salario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalarioActionPerformed(evt);
            }
        });
        jPanel1.add(Salario, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 450, 430, 30));

        TipoDocumento1.setBackground(new java.awt.Color(255, 255, 255));
        TipoDocumento1.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        TipoDocumento1.setForeground(new java.awt.Color(0, 0, 0));
        TipoDocumento1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tipo de Documento", "C.C", "C.E", "Pasaporte", "T.I", "NUI", "R.C" }));
        TipoDocumento1.setBorder(null);
        TipoDocumento1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoDocumento1ActionPerformed(evt);
            }
        });
        jPanel1.add(TipoDocumento1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 220, 30));

        Nacionalidad2.setBackground(new java.awt.Color(255, 255, 255));
        Nacionalidad2.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Nacionalidad2.setForeground(new java.awt.Color(153, 153, 153));
        Nacionalidad2.setText("Numero de la Multa");
        Nacionalidad2.setBorder(null);
        Nacionalidad2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Nacionalidad2ActionPerformed(evt);
            }
        });
        jPanel1.add(Nacionalidad2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 280, 30));

        Nacionalidad3.setBackground(new java.awt.Color(255, 255, 255));
        Nacionalidad3.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Nacionalidad3.setForeground(new java.awt.Color(153, 153, 153));
        Nacionalidad3.setText("Fecha Maxima de Pago");
        Nacionalidad3.setBorder(null);
        Nacionalidad3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Nacionalidad3ActionPerformed(evt);
            }
        });
        jPanel1.add(Nacionalidad3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 220, 280, 30));

        jScrollPane1.setBorder(null);

        jTextArea1.setBackground(new java.awt.Color(255, 255, 255));
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        jTextArea1.setForeground(new java.awt.Color(153, 153, 153));
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setText("Observaciones y Prueba");
        jTextArea1.setBorder(null);
        jScrollPane1.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 260, 430, 170));

        jScrollPane2.setBorder(null);

        jTextArea2.setBackground(new java.awt.Color(255, 255, 255));
        jTextArea2.setColumns(20);
        jTextArea2.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        jTextArea2.setForeground(new java.awt.Color(153, 153, 153));
        jTextArea2.setLineWrap(true);
        jTextArea2.setRows(5);
        jTextArea2.setText("Evento Ocurrido");
        jScrollPane2.setViewportView(jTextArea2);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 430, 170));

        jLabel1.setBackground(new java.awt.Color(204, 255, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/HOJA.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 900, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NumeroIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumeroIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumeroIdActionPerformed

    private void ApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ApellidoActionPerformed

    private void Salir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Salir1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Salir1ActionPerformed

    private void CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CancelarActionPerformed

    private void GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_GuardarActionPerformed

    private void NacionalidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NacionalidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NacionalidadActionPerformed

    private void NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreActionPerformed

    private void TelFijoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TelFijoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TelFijoActionPerformed

    private void CelularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CelularActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CelularActionPerformed

    private void ContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContraseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ContraseñaActionPerformed

    private void SalarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SalarioActionPerformed

    private void TipoDocumento1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoDocumento1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TipoDocumento1ActionPerformed

    private void Nacionalidad2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Nacionalidad2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Nacionalidad2ActionPerformed

    private void Nacionalidad3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Nacionalidad3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Nacionalidad3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GenerarMulta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GenerarMulta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GenerarMulta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GenerarMulta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GenerarMulta().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Apellido;
    private javax.swing.JButton Cancelar;
    private javax.swing.JTextField Celular;
    private javax.swing.JTextField Contraseña;
    private javax.swing.JButton Guardar;
    private javax.swing.JTextField Nacionalidad;
    private javax.swing.JTextField Nacionalidad2;
    private javax.swing.JTextField Nacionalidad3;
    private javax.swing.JTextField Nombre;
    private javax.swing.JTextField NumeroId;
    private javax.swing.JTextField Salario;
    private javax.swing.JButton Salir1;
    private javax.swing.JTextField TelFijo;
    private javax.swing.JComboBox<String> TipoDocumento1;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    // End of variables declaration//GEN-END:variables
}
