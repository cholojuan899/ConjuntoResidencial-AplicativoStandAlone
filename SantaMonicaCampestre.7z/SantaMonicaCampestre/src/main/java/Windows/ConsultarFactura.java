package Windows;


public class ConsultarFactura extends javax.swing.JFrame {

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        Titulo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Guardar = new javax.swing.JButton();
        Cancelar = new javax.swing.JButton();
        Salir1 = new javax.swing.JButton();
        NumeroId = new javax.swing.JTextField();
        TipoDocumento = new javax.swing.JComboBox<>();
        Nacionalidad = new javax.swing.JTextField();
        TelFijo = new javax.swing.JTextField();
        Celular = new javax.swing.JTextField();
        Contraseña = new javax.swing.JTextField();
        FechaInicio = new javax.swing.JTextField();
        Salario = new javax.swing.JTextField();
        TipoDocumento1 = new javax.swing.JComboBox<>();
        TipoDocumento2 = new javax.swing.JComboBox<>();
        Nacionalidad1 = new javax.swing.JTextField();
        TipoDocumento3 = new javax.swing.JComboBox<>();
        Nacionalidad2 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        Guardar1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(159, 191, 166));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator1.setToolTipText("");
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 880, 10));

        Titulo.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        Titulo.setForeground(new java.awt.Color(0, 51, 16));
        Titulo.setText("Conultar Factura");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/LETRAS.png"))); // NOI18N
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 540, -1, 50));

        Guardar.setBackground(new java.awt.Color(165, 159, 191));
        Guardar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Guardar.setForeground(new java.awt.Color(0, 0, 0));
        Guardar.setText("Buscar");
        Guardar.setToolTipText("");
        Guardar.setBorderPainted(false);
        Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarActionPerformed(evt);
            }
        });
        jPanel1.add(Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 70, -1, -1));

        Cancelar.setBackground(new java.awt.Color(92, 123, 105));
        Cancelar.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Cancelar.setForeground(new java.awt.Color(0, 0, 0));
        Cancelar.setText("Cancelar");
        Cancelar.setToolTipText("");
        Cancelar.setBorderPainted(false);
        Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarActionPerformed(evt);
            }
        });
        jPanel1.add(Cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 550, -1, -1));

        Salir1.setBackground(new java.awt.Color(92, 123, 105));
        Salir1.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Salir1.setForeground(new java.awt.Color(0, 0, 0));
        Salir1.setText("Atrás");
        Salir1.setToolTipText("");
        Salir1.setBorderPainted(false);
        Salir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Salir1ActionPerformed(evt);
            }
        });
        jPanel1.add(Salir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 10, -1, -1));

        NumeroId.setBackground(new java.awt.Color(255, 255, 255));
        NumeroId.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        NumeroId.setForeground(new java.awt.Color(153, 153, 153));
        NumeroId.setText("Numero de Documento");
        NumeroId.setToolTipText("");
        NumeroId.setBorder(null);
        NumeroId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumeroIdActionPerformed(evt);
            }
        });
        jPanel1.add(NumeroId, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 160, 650, 30));

        TipoDocumento.setBackground(new java.awt.Color(255, 255, 255));
        TipoDocumento.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        TipoDocumento.setForeground(new java.awt.Color(0, 0, 0));
        TipoDocumento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ctas Vencidas", "Si", "No" }));
        TipoDocumento.setBorder(null);
        TipoDocumento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoDocumentoActionPerformed(evt);
            }
        });
        jPanel1.add(TipoDocumento, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 260, 140, 30));

        Nacionalidad.setBackground(new java.awt.Color(255, 255, 255));
        Nacionalidad.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Nacionalidad.setForeground(new java.awt.Color(153, 153, 153));
        Nacionalidad.setText("Valor Ctas Vencidas");
        Nacionalidad.setBorder(null);
        Nacionalidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NacionalidadActionPerformed(evt);
            }
        });
        jPanel1.add(Nacionalidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 260, 280, 30));

        TelFijo.setBackground(new java.awt.Color(255, 255, 255));
        TelFijo.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        TelFijo.setForeground(new java.awt.Color(153, 153, 153));
        TelFijo.setText("Numero de Propiedad");
        TelFijo.setBorder(null);
        TelFijo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TelFijoActionPerformed(evt);
            }
        });
        jPanel1.add(TelFijo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 430, 30));

        Celular.setBackground(new java.awt.Color(255, 255, 255));
        Celular.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Celular.setForeground(new java.awt.Color(153, 153, 153));
        Celular.setText("Valor Administración");
        Celular.setBorder(null);
        Celular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CelularActionPerformed(evt);
            }
        });
        jPanel1.add(Celular, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 210, 430, 30));

        Contraseña.setBackground(new java.awt.Color(255, 255, 255));
        Contraseña.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Contraseña.setForeground(new java.awt.Color(153, 153, 153));
        Contraseña.setText("Total");
        Contraseña.setBorder(null);
        Contraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContraseñaActionPerformed(evt);
            }
        });
        jPanel1.add(Contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 360, 420, 30));

        FechaInicio.setBackground(new java.awt.Color(255, 255, 255));
        FechaInicio.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        FechaInicio.setForeground(new java.awt.Color(153, 153, 153));
        FechaInicio.setText("Numero de Factura");
        FechaInicio.setBorder(null);
        FechaInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FechaInicioActionPerformed(evt);
            }
        });
        jPanel1.add(FechaInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 430, 30));

        Salario.setBackground(new java.awt.Color(255, 255, 255));
        Salario.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Salario.setForeground(new java.awt.Color(153, 153, 153));
        Salario.setText("Fecha");
        Salario.setBorder(null);
        Salario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalarioActionPerformed(evt);
            }
        });
        jPanel1.add(Salario, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 430, 30));

        TipoDocumento1.setBackground(new java.awt.Color(255, 255, 255));
        TipoDocumento1.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        TipoDocumento1.setForeground(new java.awt.Color(0, 0, 0));
        TipoDocumento1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tipo de Documento", "C.C", "C.E", "Pasaporte", "T.I", "NUI", "R.C" }));
        TipoDocumento1.setBorder(null);
        TipoDocumento1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoDocumento1ActionPerformed(evt);
            }
        });
        jPanel1.add(TipoDocumento1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 220, 30));

        TipoDocumento2.setBackground(new java.awt.Color(255, 255, 255));
        TipoDocumento2.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        TipoDocumento2.setForeground(new java.awt.Color(0, 0, 0));
        TipoDocumento2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Descuentos", "Si", "No" }));
        TipoDocumento2.setBorder(null);
        TipoDocumento2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoDocumento2ActionPerformed(evt);
            }
        });
        jPanel1.add(TipoDocumento2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 140, 30));

        Nacionalidad1.setBackground(new java.awt.Color(255, 255, 255));
        Nacionalidad1.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Nacionalidad1.setForeground(new java.awt.Color(153, 153, 153));
        Nacionalidad1.setText("Valor Descuentos");
        Nacionalidad1.setBorder(null);
        Nacionalidad1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Nacionalidad1ActionPerformed(evt);
            }
        });
        jPanel1.add(Nacionalidad1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 310, 280, 30));

        TipoDocumento3.setBackground(new java.awt.Color(255, 255, 255));
        TipoDocumento3.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        TipoDocumento3.setForeground(new java.awt.Color(0, 0, 0));
        TipoDocumento3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Multas", "Si", "No" }));
        TipoDocumento3.setBorder(null);
        TipoDocumento3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoDocumento3ActionPerformed(evt);
            }
        });
        jPanel1.add(TipoDocumento3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 140, 30));

        Nacionalidad2.setBackground(new java.awt.Color(255, 255, 255));
        Nacionalidad2.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Nacionalidad2.setForeground(new java.awt.Color(153, 153, 153));
        Nacionalidad2.setText("Valor Multas");
        Nacionalidad2.setBorder(null);
        Nacionalidad2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Nacionalidad2ActionPerformed(evt);
            }
        });
        jPanel1.add(Nacionalidad2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, 280, 30));

        jLabel1.setBackground(new java.awt.Color(204, 255, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/HOJA.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 900, -1));

        Guardar1.setBackground(new java.awt.Color(165, 159, 191));
        Guardar1.setFont(new java.awt.Font("Montserrat", 1, 14)); // NOI18N
        Guardar1.setForeground(new java.awt.Color(0, 0, 0));
        Guardar1.setText("Generar Recibo");
        Guardar1.setToolTipText("");
        Guardar1.setBorderPainted(false);
        Guardar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Guardar1ActionPerformed(evt);
            }
        });
        jPanel1.add(Guardar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 550, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NumeroIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumeroIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumeroIdActionPerformed

    private void Salir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Salir1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Salir1ActionPerformed

    private void CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CancelarActionPerformed

    private void GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_GuardarActionPerformed

    private void TipoDocumentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoDocumentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TipoDocumentoActionPerformed

    private void NacionalidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NacionalidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NacionalidadActionPerformed

    private void TelFijoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TelFijoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TelFijoActionPerformed

    private void CelularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CelularActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CelularActionPerformed

    private void ContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContraseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ContraseñaActionPerformed

    private void FechaInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FechaInicioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FechaInicioActionPerformed

    private void SalarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SalarioActionPerformed

    private void TipoDocumento1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoDocumento1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TipoDocumento1ActionPerformed

    private void TipoDocumento2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoDocumento2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TipoDocumento2ActionPerformed

    private void Nacionalidad1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Nacionalidad1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Nacionalidad1ActionPerformed

    private void TipoDocumento3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoDocumento3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TipoDocumento3ActionPerformed

    private void Nacionalidad2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Nacionalidad2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Nacionalidad2ActionPerformed

    private void Guardar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Guardar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Guardar1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsultarFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsultarFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsultarFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsultarFactura.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsultarFactura().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cancelar;
    private javax.swing.JTextField Celular;
    private javax.swing.JTextField Contraseña;
    private javax.swing.JTextField FechaInicio;
    private javax.swing.JButton Guardar;
    private javax.swing.JButton Guardar1;
    private javax.swing.JTextField Nacionalidad;
    private javax.swing.JTextField Nacionalidad1;
    private javax.swing.JTextField Nacionalidad2;
    private javax.swing.JTextField NumeroId;
    private javax.swing.JTextField Salario;
    private javax.swing.JButton Salir1;
    private javax.swing.JTextField TelFijo;
    private javax.swing.JComboBox<String> TipoDocumento;
    private javax.swing.JComboBox<String> TipoDocumento1;
    private javax.swing.JComboBox<String> TipoDocumento2;
    private javax.swing.JComboBox<String> TipoDocumento3;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
